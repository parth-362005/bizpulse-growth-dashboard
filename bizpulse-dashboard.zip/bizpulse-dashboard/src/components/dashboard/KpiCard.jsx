import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';
import Card from '../ui/Card';

export default function KpiCard({ label, value, change, icon: Icon, tone = 'brand', delay = 0 }) {
  const positive = change >= 0;
  const tones = {
    brand: 'from-brand-500 to-violet-500',
    emerald: 'from-emerald-500 to-teal-500',
    amber: 'from-amber-500 to-orange-500',
    rose: 'from-rose-500 to-pink-500',
    sky: 'from-sky-500 to-blue-500',
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay }}
    >
      <Card hover className="p-5 relative overflow-hidden">
        <div className={`absolute -right-6 -top-6 w-24 h-24 rounded-full bg-gradient-to-br ${tones[tone]} opacity-10`} />
        <div className="flex items-start justify-between">
          <p className="text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide">{label}</p>
          {Icon && (
            <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${tones[tone]} flex items-center justify-center shadow-soft`}>
              <Icon className="w-4.5 h-4.5 text-white" strokeWidth={2} />
            </div>
          )}
        </div>
        <p className="mt-3 text-2xl font-display font-bold text-ink-900 dark:text-white">{value}</p>
        {change !== undefined && (
          <div className={`mt-2 inline-flex items-center gap-1 text-xs font-medium ${positive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
            {positive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
            {Math.abs(change)}% vs last period
          </div>
        )}
      </Card>
    </motion.div>
  );
}
