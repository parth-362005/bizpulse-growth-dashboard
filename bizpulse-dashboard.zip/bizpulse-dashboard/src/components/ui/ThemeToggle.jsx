import { Moon, Sun } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

export default function ThemeToggle({ className = '' }) {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      aria-label="Toggle theme"
      className={`relative w-16 h-9 rounded-full border border-ink-200 dark:border-ink-700 bg-ink-100 dark:bg-ink-800 transition-colors ${className}`}
    >
      <span
        className={`absolute top-1 left-1 w-7 h-7 rounded-full bg-white dark:bg-ink-950 shadow-soft flex items-center justify-center transition-transform duration-300 ${
          theme === 'dark' ? 'translate-x-7' : 'translate-x-0'
        }`}
      >
        {theme === 'dark' ? <Moon className="w-3.5 h-3.5 text-brand-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
      </span>
    </button>
  );
}
