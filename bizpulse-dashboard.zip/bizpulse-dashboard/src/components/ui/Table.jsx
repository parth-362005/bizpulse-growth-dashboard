export default function Table({ columns, children, className = '' }) {
  return (
    <div className="overflow-x-auto scrollbar-thin -mx-1">
      <table className={`w-full text-sm border-collapse ${className}`}>
        <thead>
          <tr className="border-b border-ink-100 dark:border-ink-800">
            {columns.map((col) => (
              <th
                key={col.key || col}
                className="text-left font-medium text-ink-500 dark:text-ink-400 px-3 py-3 whitespace-nowrap text-xs uppercase tracking-wide"
              >
                {col.label || col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export function Tr({ children, className = '' }) {
  return (
    <tr className={`border-b border-ink-50 dark:border-ink-800/60 hover:bg-ink-50/70 dark:hover:bg-ink-800/40 transition-colors ${className}`}>
      {children}
    </tr>
  );
}

export function Td({ children, className = '' }) {
  return <td className={`px-3 py-3.5 align-middle text-ink-700 dark:text-ink-200 ${className}`}>{children}</td>;
}
