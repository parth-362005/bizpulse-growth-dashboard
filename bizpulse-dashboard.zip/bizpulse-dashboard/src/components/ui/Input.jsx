import { forwardRef } from 'react';

const Input = forwardRef(function Input(
  { label, error, icon: Icon, className = '', containerClassName = '', hint, ...props },
  ref
) {
  return (
    <div className={`flex flex-col gap-1.5 ${containerClassName}`}>
      {label && <label className="text-sm font-medium text-ink-700 dark:text-ink-200">{label}</label>}
      <div className="relative">
        {Icon && <Icon className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />}
        <input
          ref={ref}
          className={`w-full bg-white dark:bg-ink-900 border ${
            error ? 'border-rose-400 focus:ring-rose-400' : 'border-ink-200 dark:border-ink-700 focus:ring-brand-500'
          } rounded-xl px-4 py-2.5 ${Icon ? 'pl-10' : ''} text-sm text-ink-900 dark:text-ink-100 placeholder:text-ink-400 outline-none focus:ring-2 transition-all ${className}`}
          {...props}
        />
      </div>
      {hint && !error && <span className="text-xs text-ink-400">{hint}</span>}
      {error && <span className="text-xs text-rose-500">{error}</span>}
    </div>
  );
});

export default Input;
