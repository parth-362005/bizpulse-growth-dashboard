import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, XCircle, Info, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';

const icons = { success: CheckCircle2, error: XCircle, info: Info };
const styles = {
  success: 'border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-400',
  error: 'border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-400',
  info: 'border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-400',
};

export default function ToastContainer() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="fixed bottom-5 right-5 z-[100] flex flex-col gap-2 w-full max-w-sm">
      <AnimatePresence>
        {toasts.map((t) => {
          const Icon = icons[t.type] || Info;
          return (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, x: 40, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 40, scale: 0.95 }}
              className={`glass rounded-xl shadow-card border px-4 py-3 flex items-center gap-3 ${styles[t.type]}`}
            >
              <Icon className="w-5 h-5 shrink-0" />
              <p className="text-sm font-medium flex-1 text-ink-800 dark:text-ink-100">{t.message}</p>
              <button onClick={() => dismissToast(t.id)} className="text-ink-400 hover:text-ink-600">
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
