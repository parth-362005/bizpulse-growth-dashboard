import { Search, X } from 'lucide-react';

export default function SearchBar({ value, onChange, placeholder = 'Search...', className = '' }) {
  return (
    <div className={`relative ${className}`}>
      <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl pl-10 pr-9 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500 placeholder:text-ink-400 transition-all"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-600 dark:hover:text-ink-200"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
