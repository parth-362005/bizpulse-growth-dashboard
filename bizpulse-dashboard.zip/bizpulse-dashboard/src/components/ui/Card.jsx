export default function Card({ children, className = '', hover = false, as: Comp = 'div', ...props }) {
  return (
    <Comp className={`card ${hover ? 'card-hover' : ''} ${className}`} {...props}>
      {children}
    </Comp>
  );
}
