import { Menu, Search, Bell, ChevronRight, User, Settings, LogOut, CircleHelp } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import ThemeToggle from '../ui/ThemeToggle';
import Avatar from '../ui/Avatar';
import Badge from '../ui/Badge';
import Dropdown, { DropdownItem } from '../ui/Dropdown';
import { currentUser } from '../../data/business';
import { appNotifications } from '../../data/notifications';
import { navItems } from './Sidebar';

export default function Navbar() {
  const { setMobileSidebarOpen, business, pushToast } = useApp();
  const location = useLocation();
  const [query, setQuery] = useState('');

  const current = navItems.find((n) => location.pathname.startsWith(n.to));
  const unreadCount = appNotifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-20 h-16 glass border-b border-ink-100 dark:border-ink-800 flex items-center gap-3 px-4 lg:px-6">
      <button className="lg:hidden text-ink-500" onClick={() => setMobileSidebarOpen(true)}>
        <Menu className="w-5 h-5" />
      </button>

      {/* Breadcrumb */}
      <div className="hidden md:flex items-center gap-1.5 text-sm min-w-fit">
        <span className="font-display font-semibold text-ink-900 dark:text-white">{business.name}</span>
        {current && (
          <>
            <ChevronRight className="w-3.5 h-3.5 text-ink-300" />
            <span className="text-ink-500">{current.label}</span>
          </>
        )}
      </div>

      {/* Global search */}
      <div className="flex-1 max-w-md ml-2 hidden sm:block">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && query.trim()) {
                pushToast(`Showing results for "${query}"`, 'info');
              }
            }}
            placeholder="Search products, customers, invoices..."
            className="w-full bg-ink-100/70 dark:bg-ink-800/70 border border-transparent focus:border-brand-300 focus:bg-white dark:focus:bg-ink-900 rounded-xl pl-10 pr-4 py-2 text-sm outline-none transition-all placeholder:text-ink-400"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        <ThemeToggle className="hidden sm:flex" />

        {/* Notifications */}
        <Dropdown
          trigger={
            <button className="relative p-2.5 rounded-xl hover:bg-ink-100 dark:hover:bg-ink-800 text-ink-500 dark:text-ink-300 transition">
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white dark:ring-ink-900" />
              )}
            </button>
          }
          className="w-80 !p-0"
        >
          <div className="px-4 py-3 border-b border-ink-100 dark:border-ink-800 flex items-center justify-between">
            <p className="font-semibold text-sm text-ink-900 dark:text-white">Notifications</p>
            <Badge tone="brand">{unreadCount} new</Badge>
          </div>
          <div className="max-h-80 overflow-y-auto scrollbar-thin">
            {appNotifications.map((n) => (
              <div key={n.id} className={`px-4 py-3 border-b border-ink-50 dark:border-ink-800/60 last:border-0 ${!n.read ? 'bg-brand-50/40 dark:bg-brand-500/5' : ''}`}>
                <p className="text-sm font-medium text-ink-800 dark:text-ink-100">{n.title}</p>
                <p className="text-xs text-ink-500 mt-0.5">{n.message}</p>
                <p className="text-[11px] text-ink-400 mt-1">{n.time}</p>
              </div>
            ))}
          </div>
          <div className="p-2">
            <Link to="/notifications" className="block text-center text-xs font-medium text-brand-600 hover:underline py-2">
              View all notifications
            </Link>
          </div>
        </Dropdown>

        {/* Profile */}
        <Dropdown
          trigger={
            <button className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-xl hover:bg-ink-100 dark:hover:bg-ink-800 transition">
              <Avatar initials={currentUser.avatarInitials} size="sm" />
              <div className="hidden md:block text-left">
                <p className="text-xs font-semibold text-ink-800 dark:text-ink-100 leading-tight">{currentUser.name}</p>
                <p className="text-[11px] text-ink-400 leading-tight">{currentUser.role}</p>
              </div>
            </button>
          }
        >
          <div className="px-3 py-2 border-b border-ink-100 dark:border-ink-800 mb-1">
            <p className="text-sm font-medium text-ink-800 dark:text-ink-100">{currentUser.name}</p>
            <p className="text-xs text-ink-400">{currentUser.email}</p>
          </div>
          <DropdownItem icon={User} onClick={() => pushToast('Opening your profile...', 'info')}>My Profile</DropdownItem>
          <Link to="/settings"><DropdownItem icon={Settings}>Settings</DropdownItem></Link>
          <DropdownItem icon={CircleHelp} onClick={() => pushToast('Opening help center...', 'info')}>Help & Support</DropdownItem>
          <DropdownItem icon={LogOut} danger onClick={() => pushToast('You have been logged out (demo mode).', 'info')}>Logout</DropdownItem>
        </Dropdown>
      </div>
    </header>
  );
}
