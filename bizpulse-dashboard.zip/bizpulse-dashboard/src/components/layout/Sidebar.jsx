import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Boxes,
  ShoppingCart,
  Users,
  FileText,
  LineChart,
  Sparkles,
  Receipt,
  MessageCircle,
  UserCog,
  Settings,
  LogOut,
  ChevronsLeft,
  ChevronsRight,
  Zap,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/inventory', label: 'Inventory', icon: Boxes },
  { to: '/sales', label: 'Sales', icon: ShoppingCart },
  { to: '/customers', label: 'Customers', icon: Users },
  { to: '/invoices', label: 'Invoices', icon: FileText },
  { to: '/analytics', label: 'Profit Analytics', icon: LineChart },
  { to: '/prediction', label: 'AI Sales Prediction', icon: Sparkles, badge: 'AI' },
  { to: '/gst', label: 'GST Reports', icon: Receipt },
  { to: '/notifications', label: 'WhatsApp Notifications', icon: MessageCircle },
  { to: '/employees', label: 'Employee Management', icon: UserCog },
  { to: '/settings', label: 'Settings', icon: Settings },
];

export default function Sidebar() {
  const { sidebarCollapsed, setSidebarCollapsed, mobileSidebarOpen, setMobileSidebarOpen, pushToast } = useApp();

  const content = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={`flex items-center gap-3 px-4 h-16 shrink-0 ${sidebarCollapsed ? 'justify-center' : ''}`}>
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-violet-600 flex items-center justify-center shadow-glow shrink-0">
          <Zap className="w-5 h-5 text-white" fill="white" />
        </div>
        {!sidebarCollapsed && (
          <div className="overflow-hidden">
            <p className="font-display font-bold text-ink-900 dark:text-white text-sm leading-tight whitespace-nowrap">BizPulse</p>
            <p className="text-[11px] text-ink-400 whitespace-nowrap">Growth Dashboard</p>
          </div>
        )}
        <button
          className="ml-auto lg:hidden text-ink-400 hover:text-ink-700 dark:hover:text-ink-200"
          onClick={() => setMobileSidebarOpen(false)}
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin px-3 py-2 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            onClick={() => setMobileSidebarOpen(false)}
            className={({ isActive }) =>
              `group flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all relative ${
                isActive
                  ? 'bg-gradient-to-r from-brand-600 to-violet-600 text-white shadow-soft'
                  : 'text-ink-600 dark:text-ink-300 hover:bg-ink-100 dark:hover:bg-ink-800/70'
              } ${sidebarCollapsed ? 'justify-center' : ''}`
            }
            title={sidebarCollapsed ? item.label : undefined}
          >
            <item.icon className="w-[18px] h-[18px] shrink-0" strokeWidth={2} />
            {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
            {!sidebarCollapsed && item.badge && (
              <span className="ml-auto text-[10px] font-bold bg-white/20 px-1.5 py-0.5 rounded-full">{item.badge}</span>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Bottom */}
      <div className="p-3 border-t border-ink-100 dark:border-ink-800 space-y-1">
        <button
          onClick={() => pushToast('You have been logged out (demo mode).', 'info')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-ink-600 dark:text-ink-300 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10 dark:hover:text-rose-400 transition-all ${
            sidebarCollapsed ? 'justify-center' : ''
          }`}
        >
          <LogOut className="w-[18px] h-[18px] shrink-0" />
          {!sidebarCollapsed && 'Logout'}
        </button>
        <button
          onClick={() => setSidebarCollapsed((c) => !c)}
          className="hidden lg:flex w-full items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-ink-400 hover:bg-ink-100 dark:hover:bg-ink-800/70 transition-all justify-center"
        >
          {sidebarCollapsed ? <ChevronsRight className="w-[18px] h-[18px]" /> : <ChevronsLeft className="w-[18px] h-[18px]" />}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={`hidden lg:block fixed top-0 left-0 h-screen bg-white/90 dark:bg-ink-900/90 backdrop-blur-xl border-r border-ink-100 dark:border-ink-800 transition-all duration-300 z-30 ${
          sidebarCollapsed ? 'w-[76px]' : 'w-64'
        }`}
      >
        {content}
      </aside>

      {/* Mobile sidebar */}
      {mobileSidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-ink-950/60 backdrop-blur-sm" onClick={() => setMobileSidebarOpen(false)} />
          <aside className="relative w-72 h-full bg-white dark:bg-ink-900 border-r border-ink-100 dark:border-ink-800 animate-slide-up">
            {content}
          </aside>
        </div>
      )}
    </>
  );
}

export { navItems };
