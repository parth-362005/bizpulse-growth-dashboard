import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Download, FileSpreadsheet, Receipt } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import ChartCard from '../components/dashboard/ChartCard';
import Table, { Tr, Td } from '../components/ui/Table';
import Badge from '../components/ui/Badge';
import { monthlyGST, quarterlyGST, gstRateSummary } from '../data/notifications';
import { formatCurrency } from '../utils/format';
import { useApp } from '../context/AppContext';

export default function GST() {
  const { pushToast } = useApp();
  const [view, setView] = useState('monthly');
  const data = view === 'monthly' ? monthlyGST : quarterlyGST;
  const xKey = view === 'monthly' ? 'month' : 'quarter';

  const totalSalesTax = gstRateSummary.reduce((s, r) => s + r.taxAmount, 0);
  const totalTaxable = gstRateSummary.reduce((s, r) => s + r.taxableValue, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">GST Reports</h1>
          <p className="text-sm text-ink-500 mt-1">Sales tax, purchase tax, and filing-ready summaries.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" icon={FileSpreadsheet} onClick={() => pushToast('GST report exported to Excel.', 'success')}>Export Excel</Button>
          <Button icon={Download} onClick={() => pushToast('GST report PDF downloaded.', 'success')}>Download PDF</Button>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="p-5">
          <p className="text-xs text-ink-500">Total Taxable Value</p>
          <p className="text-2xl font-bold text-ink-900 dark:text-white mt-1">{formatCurrency(totalTaxable)}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs text-ink-500">Total GST Collected</p>
          <p className="text-2xl font-bold text-brand-600 mt-1">{formatCurrency(totalSalesTax)}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs text-ink-500">Net Payable (Sales - Purchase)</p>
          <p className="text-2xl font-bold text-emerald-600 mt-1">{formatCurrency(monthlyGST[monthlyGST.length - 1].net)}</p>
        </Card>
      </div>

      <ChartCard
        title="Tax Summary"
        subtitle="Sales tax vs purchase tax"
        action={
          <div className="flex bg-ink-100 dark:bg-ink-800 rounded-lg p-1 text-xs">
            {['monthly', 'quarterly'].map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-3 py-1.5 rounded-md capitalize font-medium transition ${view === v ? 'bg-white dark:bg-ink-700 shadow-soft text-ink-800 dark:text-white' : 'text-ink-500'}`}
              >
                {v}
              </button>
            ))}
          </div>
        }
      >
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
            <XAxis dataKey={xKey} tick={{ fontSize: 11, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
            <Tooltip formatter={(v) => formatCurrency(v)} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="salesTax" fill="#6366f1" radius={[6, 6, 0, 0]} name="Sales Tax" />
            <Bar dataKey="purchaseTax" fill="#c7d2fe" radius={[6, 6, 0, 0]} name="Purchase Tax" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <div className="grid lg:grid-cols-2 gap-5">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <Receipt className="w-4 h-4 text-brand-600" />
            <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white">GST Rate-wise Summary</h3>
          </div>
          <Table columns={['GST Rate', 'Taxable Value', 'Tax Amount']}>
            {gstRateSummary.map((r) => (
              <Tr key={r.rate}>
                <Td><Badge tone="brand">{r.rate}</Badge></Td>
                <Td>{formatCurrency(r.taxableValue)}</Td>
                <Td className="font-medium">{formatCurrency(r.taxAmount)}</Td>
              </Tr>
            ))}
          </Table>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-4">
            {view === 'monthly' ? 'Monthly' : 'Quarterly'} Filing Status
          </h3>
          <Table columns={[view === 'monthly' ? 'Month' : 'Quarter', 'Net Tax', 'Status']}>
            {data.map((d) => (
              <Tr key={d[xKey]}>
                <Td>{d[xKey]}</Td>
                <Td className="font-medium">{formatCurrency(d.net)}</Td>
                <Td><Badge tone="success">Filed</Badge></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </div>
  );
}
