import { Link } from 'react-router-dom';
import { Home, SearchX } from 'lucide-react';
import Button from '../components/ui/Button';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-ink-50 dark:bg-ink-950 p-4">
      <div className="text-center max-w-sm">
        <div className="w-20 h-20 rounded-3xl bg-brand-100 dark:bg-brand-500/10 flex items-center justify-center mx-auto mb-6">
          <SearchX className="w-9 h-9 text-brand-600" />
        </div>
        <h1 className="font-display text-6xl font-bold text-ink-900 dark:text-white mb-2">404</h1>
        <p className="text-ink-500 mb-8">The page you're looking for doesn't exist or has been moved.</p>
        <Link to="/dashboard">
          <Button icon={Home} size="lg">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
}
