import { useMemo, useState } from 'react';
import { FileText, Printer, Download, QrCode, Search } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import SearchBar from '../components/ui/SearchBar';
import Badge from '../components/ui/Badge';
import Table, { Tr, Td } from '../components/ui/Table';
import Pagination from '../components/ui/Pagination';
import Modal from '../components/ui/Modal';
import EmptyState from '../components/ui/EmptyState';
import { invoices as allInvoices } from '../data/invoices';
import { businessProfile } from '../data/business';
import { formatCurrency, formatDate } from '../utils/format';
import { useApp } from '../context/AppContext';

const PAGE_SIZE = 8;
const statusTone = { Paid: 'success', Pending: 'warning', Overdue: 'danger' };

export default function Invoices() {
  const { pushToast } = useApp();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);

  const filtered = useMemo(
    () =>
      allInvoices.filter(
        (i) =>
          (i.id.toLowerCase().includes(search.toLowerCase()) || i.customer.toLowerCase().includes(search.toLowerCase())) &&
          (status === 'All' || i.status === status)
      ),
    [search, status]
  );
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const totals = useMemo(
    () => ({
      count: allInvoices.length,
      paid: allInvoices.filter((i) => i.status === 'Paid').reduce((s, i) => s + i.grandTotal, 0),
      pending: allInvoices.filter((i) => i.status !== 'Paid').reduce((s, i) => s + i.grandTotal, 0),
    }),
    []
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Invoices</h1>
        <p className="text-sm text-ink-500 mt-1">{totals.count} invoices generated · {formatCurrency(totals.paid, { compact: true })} collected</p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="p-4">
          <p className="text-xs text-ink-500">Total Invoices</p>
          <p className="text-xl font-bold text-ink-900 dark:text-white mt-1">{totals.count}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-ink-500">Amount Collected</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">{formatCurrency(totals.paid, { compact: true })}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-ink-500">Pending / Overdue</p>
          <p className="text-xl font-bold text-rose-600 mt-1">{formatCurrency(totals.pending, { compact: true })}</p>
        </Card>
      </div>

      <Card className="p-5">
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <SearchBar value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="Search invoice # or customer..." className="sm:max-w-xs" />
          <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            <option>All</option>
            <option>Paid</option>
            <option>Pending</option>
            <option>Overdue</option>
          </select>
        </div>

        {paged.length === 0 ? (
          <EmptyState icon={Search} title="No invoices found" />
        ) : (
          <>
            <Table columns={['Invoice #', 'Customer', 'Date', 'Items', 'GST', 'Total', 'Status', 'Actions']}>
              {paged.map((inv) => (
                <Tr key={inv.id}>
                  <Td className="font-medium text-ink-900 dark:text-white">{inv.id}</Td>
                  <Td>{inv.customer}</Td>
                  <Td className="text-xs">{formatDate(inv.date)}</Td>
                  <Td>{inv.items.length}</Td>
                  <Td>{formatCurrency(inv.gstTotal)}</Td>
                  <Td className="font-medium">{formatCurrency(inv.grandTotal)}</Td>
                  <Td><Badge tone={statusTone[inv.status]}>{inv.status}</Badge></Td>
                  <Td>
                    <Button size="sm" variant="secondary" icon={FileText} onClick={() => setSelected(inv)}>View</Button>
                  </Td>
                </Tr>
              ))}
            </Table>
            <Pagination page={page} totalPages={totalPages} onPageChange={setPage} totalItems={filtered.length} pageSize={PAGE_SIZE} />
          </>
        )}
      </Card>

      <Modal
        open={!!selected}
        onClose={() => setSelected(null)}
        title={`Invoice ${selected?.id || ''}`}
        size="lg"
        footer={
          <>
            <Button variant="secondary" icon={Printer} onClick={() => pushToast('Sending invoice to printer...', 'info')}>Print</Button>
            <Button icon={Download} onClick={() => pushToast('Invoice PDF downloaded (demo).', 'success')}>Download PDF</Button>
          </>
        }
      >
        {selected && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-500 to-violet-600 flex items-center justify-center text-white font-display font-bold">
                  {businessProfile.logoInitials}
                </div>
                <div>
                  <p className="font-display font-bold text-ink-900 dark:text-white">{businessProfile.name}</p>
                  <p className="text-xs text-ink-400">{businessProfile.address}</p>
                  <p className="text-xs text-ink-400">GSTIN: {businessProfile.gstNumber}</p>
                </div>
              </div>
              <div className="w-16 h-16 rounded-lg bg-ink-100 dark:bg-ink-800 flex items-center justify-center">
                <QrCode className="w-9 h-9 text-ink-400" />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-800/50">
                <p className="text-ink-400 mb-1">Billed To</p>
                <p className="font-medium text-ink-800 dark:text-ink-100">{selected.customer}</p>
                <p className="text-ink-500">{selected.customerPhone}</p>
              </div>
              <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-800/50">
                <p className="text-ink-400 mb-1">Invoice Details</p>
                <p className="text-ink-600 dark:text-ink-300">Invoice #: <span className="font-medium text-ink-800 dark:text-ink-100">{selected.id}</span></p>
                <p className="text-ink-600 dark:text-ink-300">Date: {formatDate(selected.date)}</p>
              </div>
            </div>

            <div>
              <Table columns={['Item', 'Qty', 'Price', 'GST %', 'Total']}>
                {selected.items.map((item, i) => (
                  <Tr key={i}>
                    <Td>{item.name}</Td>
                    <Td>{item.qty}</Td>
                    <Td>{formatCurrency(item.price)}</Td>
                    <Td>{item.gstRate}%</Td>
                    <Td className="font-medium">{formatCurrency(item.total)}</Td>
                  </Tr>
                ))}
              </Table>
            </div>

            <div className="flex justify-end">
              <div className="w-full sm:w-64 space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-ink-500">Subtotal</span><span>{formatCurrency(selected.subtotal)}</span></div>
                <div className="flex justify-between"><span className="text-ink-500">GST</span><span>{formatCurrency(selected.gstTotal)}</span></div>
                <div className="flex justify-between"><span className="text-ink-500">Discount</span><span>-{formatCurrency(selected.discount)}</span></div>
                <div className="flex justify-between text-base font-bold pt-2 border-t border-ink-100 dark:border-ink-800">
                  <span>Grand Total</span><span className="text-brand-600">{formatCurrency(selected.grandTotal)}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
