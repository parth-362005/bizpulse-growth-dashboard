import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { Zap, Mail, Lock, Eye, EyeOff, ArrowRight, BarChart3, ShieldCheck, Sparkles } from 'lucide-react';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { useApp } from '../context/AppContext';

export default function Login() {
  const navigate = useNavigate();
  const { pushToast } = useApp();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: { email: 'rajesh@shreeganeshstore.in', password: 'demo1234' },
  });

  const onSubmit = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      pushToast('Welcome back, Rajesh! Login successful.', 'success');
      navigate('/dashboard');
    }, 900);
  };

  return (
    <div className="min-h-screen w-full bg-ink-950 relative overflow-hidden flex items-center justify-center p-4">
      {/* Ambient background */}
      <div className="absolute inset-0 bg-grid opacity-40" />
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-brand-600/30 rounded-full blur-[120px]" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-fuchsia-600/20 rounded-full blur-[120px]" />

      <div className="relative w-full max-w-5xl grid lg:grid-cols-2 rounded-3xl overflow-hidden shadow-2xl border border-white/10">
        {/* Left illustration panel */}
        <div className="hidden lg:flex flex-col justify-between p-10 bg-gradient-to-br from-brand-700 via-brand-600 to-violet-700 relative overflow-hidden">
          <div className="absolute inset-0 bg-grid opacity-20" />
          <div className="relative flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center backdrop-blur">
              <Zap className="w-5 h-5 text-white" fill="white" />
            </div>
            <span className="font-display font-bold text-white text-lg">BizPulse</span>
          </div>

          <div className="relative space-y-6">
            <h2 className="font-display text-3xl font-bold text-white leading-tight">
              Run your shop like a data-driven business.
            </h2>
            <p className="text-brand-100/90 text-sm leading-relaxed max-w-sm">
              Track sales, inventory, GST and profit in one elegant dashboard — built for local businesses that want to grow.
            </p>
            <div className="space-y-3 pt-2">
              {[
                { icon: BarChart3, text: 'Real-time sales & profit analytics' },
                { icon: Sparkles, text: 'AI-powered demand forecasting' },
                { icon: ShieldCheck, text: 'Secure billing & GST-ready invoices' },
              ].map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.15 * i + 0.2 }}
                  className="flex items-center gap-3 text-white/90 text-sm"
                >
                  <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center backdrop-blur">
                    <f.icon className="w-4 h-4" />
                  </div>
                  {f.text}
                </motion.div>
              ))}
            </div>
          </div>

          <p className="relative text-xs text-brand-100/70">Trusted by 4,200+ local businesses across India</p>
        </div>

        {/* Right form panel */}
        <div className="glass p-8 sm:p-12 flex flex-col justify-center">
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
            <div className="lg:hidden flex items-center gap-2.5 mb-8">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-violet-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" fill="white" />
              </div>
              <span className="font-display font-bold text-white text-lg">BizPulse</span>
            </div>

            <h1 className="font-display text-2xl font-bold text-white mb-1">Welcome back 👋</h1>
            <p className="text-ink-300 text-sm mb-8">Sign in to Shree Ganesh General Store's dashboard.</p>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-ink-200 mb-1.5 block">Email address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                  <input
                    {...register('email', { required: 'Email is required' })}
                    className="w-full bg-white/5 border border-white/10 focus:border-brand-400 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-ink-500 outline-none focus:ring-2 focus:ring-brand-500/40 transition-all"
                    placeholder="you@business.com"
                  />
                </div>
                {errors.email && <p className="text-xs text-rose-400 mt-1">{errors.email.message}</p>}
              </div>

              <div>
                <label className="text-sm font-medium text-ink-200 mb-1.5 block">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    {...register('password', { required: 'Password is required' })}
                    className="w-full bg-white/5 border border-white/10 focus:border-brand-400 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder:text-ink-500 outline-none focus:ring-2 focus:ring-brand-500/40 transition-all"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.password && <p className="text-xs text-rose-400 mt-1">{errors.password.message}</p>}
              </div>

              <div className="flex items-center justify-between text-sm pt-1">
                <label className="flex items-center gap-2 text-ink-300 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded border-white/20 bg-white/5 text-brand-500 focus:ring-brand-500" />
                  Remember me
                </label>
                <button type="button" onClick={() => pushToast('Password reset link sent to your email.', 'info')} className="text-brand-400 hover:text-brand-300 font-medium">
                  Forgot password?
                </button>
              </div>

              <Button type="submit" loading={loading} className="w-full mt-2" size="lg" iconRight={ArrowRight}>
                Sign In to Dashboard
              </Button>
            </form>

            <p className="text-xs text-ink-500 text-center mt-6">
              This is a demo — click Sign In with the pre-filled details to explore BizPulse.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
