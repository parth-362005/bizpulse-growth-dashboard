import {
  IndianRupee, ShoppingBag, TrendingUp, PackageX, Users, Wallet,
  FileText, UserCheck, PackagePlus, MessageCircle, UserPlus, Lightbulb, ArrowRight,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import KpiCard from '../components/dashboard/KpiCard';
import ChartCard from '../components/dashboard/ChartCard';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Table, { Tr, Td } from '../components/ui/Table';
import { Link } from 'react-router-dom';
import {
  weeklySales, monthlyRevenue, profitTrend, revenueDistribution, topProducts,
  recentOrders, todayStats,
} from '../data/sales';
import { recentActivities, businessTips, appNotifications } from '../data/notifications';
import { formatCurrency, timeAgo } from '../utils/format';

const activityIcons = { FileText, UserCheck, PackagePlus, IndianRupee, MessageCircle, UserPlus };
const PIE_COLORS = ['#6366f1', '#8b5cf6', '#d946ef', '#f59e0b', '#10b981', '#0ea5e9', '#94a3b8'];

const statusTone = { Completed: 'success', Pending: 'warning', Processing: 'info', Cancelled: 'danger' };

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Good morning, Rajesh 👋</h1>
          <p className="text-sm text-ink-500 mt-1">Here's how Shree Ganesh General Store is performing today.</p>
        </div>
        <Badge tone="success" dot>All systems normal</Badge>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiCard label="Today's Sales" value={formatCurrency(todayStats.todaySales)} change={todayStats.todaySalesChange} icon={IndianRupee} tone="brand" delay={0.0} />
        <KpiCard label="Today's Orders" value={todayStats.todayOrders} change={todayStats.todayOrdersChange} icon={ShoppingBag} tone="sky" delay={0.05} />
        <KpiCard label="Monthly Revenue" value={formatCurrency(todayStats.monthlyRevenue, { compact: true })} change={todayStats.monthlyRevenueChange} icon={TrendingUp} tone="emerald" delay={0.1} />
        <KpiCard label="Net Profit" value={formatCurrency(todayStats.netProfit, { compact: true })} change={todayStats.netProfitChange} icon={Wallet} tone="amber" delay={0.15} />
        <KpiCard label="Low Stock Items" value={todayStats.lowStockCount} icon={PackageX} tone="rose" delay={0.2} />
        <KpiCard label="Total Customers" value={todayStats.totalCustomers} change={todayStats.totalCustomersChange} icon={Users} tone="brand" delay={0.25} />
      </div>

      {/* Charts row 1 */}
      <div className="grid lg:grid-cols-3 gap-5">
        <ChartCard title="Weekly Sales" subtitle="Sales & order volume, last 7 days" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={weeklySales}>
              <defs>
                <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
              <Tooltip
                contentStyle={{ borderRadius: 12, border: '1px solid #eee', fontSize: 12 }}
                formatter={(value, name) => [name === 'sales' ? formatCurrency(value) : value, name === 'sales' ? 'Sales' : 'Orders']}
              />
              <Area type="monotone" dataKey="sales" stroke="#6366f1" strokeWidth={2.5} fill="url(#salesGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Revenue Distribution" subtitle="By category this month">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={revenueDistribution} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
                {revenueDistribution.map((entry, i) => (
                  <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(v) => `${v}%`} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 mt-2">
            {revenueDistribution.map((d, i) => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs text-ink-500">
                <span className="w-2 h-2 rounded-full shrink-0" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                {d.name} · {d.value}%
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      {/* Charts row 2 */}
      <div className="grid lg:grid-cols-3 gap-5">
        <ChartCard title="Monthly Revenue" subtitle="Revenue vs expenses (₹ in thousands)" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={monthlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip formatter={(v) => formatCurrency(v)} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="revenue" fill="#6366f1" radius={[6, 6, 0, 0]} name="Revenue" />
              <Bar dataKey="expenses" fill="#e0e7ff" radius={[6, 6, 0, 0]} name="Expenses" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Profit Trend" subtitle="Margin % over time">
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={profitTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#8c8ca3' }} axisLine={false} tickLine={false} interval={1} />
              <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v) => `${v}%`} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Line type="monotone" dataKey="margin" stroke="#10b981" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Tables row */}
      <div className="grid lg:grid-cols-3 gap-5">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white">Recent Orders</h3>
            <Link to="/sales" className="text-xs font-medium text-brand-600 hover:underline flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <Table columns={['Order', 'Customer', 'Items', 'Amount', 'Payment', 'Status']}>
            {recentOrders.slice(0, 6).map((o) => (
              <Tr key={o.id}>
                <Td className="font-medium text-ink-900 dark:text-white">{o.id}</Td>
                <Td>{o.customer}</Td>
                <Td>{o.items}</Td>
                <Td className="font-medium">{formatCurrency(o.amount)}</Td>
                <Td>{o.payment}</Td>
                <Td><Badge tone={statusTone[o.status]}>{o.status}</Badge></Td>
              </Tr>
            ))}
          </Table>
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivities.map((a) => {
              const Icon = activityIcons[a.icon] || FileText;
              return (
                <div key={a.id} className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-brand-50 dark:bg-brand-500/10 text-brand-600 dark:text-brand-400 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs text-ink-700 dark:text-ink-200 leading-snug">{a.text}</p>
                    <p className="text-[11px] text-ink-400 mt-0.5">{a.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Bottom row: Top products, notifications, tips */}
      <div className="grid lg:grid-cols-3 gap-5">
        <Card className="p-5">
          <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-4">Top Products</h3>
          <div className="space-y-3">
            {topProducts.slice(0, 5).map((p, i) => (
              <div key={p.name} className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-md bg-ink-100 dark:bg-ink-800 text-ink-500 text-xs font-semibold flex items-center justify-center shrink-0">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-ink-800 dark:text-ink-100 truncate">{p.name}</p>
                  <p className="text-xs text-ink-400">{p.unitsSold} units sold</p>
                </div>
                <p className="text-sm font-medium text-ink-900 dark:text-white shrink-0">{formatCurrency(p.revenue, { compact: true })}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white">Notifications</h3>
            <Link to="/notifications" className="text-xs font-medium text-brand-600 hover:underline">View all</Link>
          </div>
          <div className="space-y-3">
            {appNotifications.slice(0, 4).map((n) => (
              <div key={n.id} className="flex gap-2.5">
                <span className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${n.read ? 'bg-ink-300' : 'bg-brand-500'}`} />
                <div>
                  <p className="text-xs font-medium text-ink-800 dark:text-ink-100">{n.title}</p>
                  <p className="text-[11px] text-ink-400">{n.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5 bg-gradient-to-br from-brand-600 to-violet-700 text-white border-none">
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="w-5 h-5" />
            <h3 className="font-display font-semibold text-sm">Business Tip</h3>
          </div>
          <p className="text-sm text-white/90 leading-relaxed">{businessTips[0]}</p>
          <div className="mt-4 pt-4 border-t border-white/20 space-y-2">
            {businessTips.slice(1, 3).map((tip, i) => (
              <p key={i} className="text-xs text-white/70 leading-relaxed">• {tip}</p>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
