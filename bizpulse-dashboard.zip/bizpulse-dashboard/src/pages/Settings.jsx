import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Building2, Bell, Palette, Database, Globe, User, Save } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import ThemeToggle from '../components/ui/ThemeToggle';
import Avatar from '../components/ui/Avatar';
import { useApp } from '../context/AppContext';
import { currentUser } from '../data/business';

const tabs = [
  { id: 'business', label: 'Business Profile', icon: Building2 },
  { id: 'profile', label: 'Profile Settings', icon: User },
  { id: 'theme', label: 'Theme Settings', icon: Palette },
  { id: 'notifications', label: 'Notification Settings', icon: Bell },
  { id: 'backup', label: 'Backup Data', icon: Database },
  { id: 'language', label: 'Language', icon: Globe },
];

export default function Settings() {
  const { business, setBusiness, pushToast } = useApp();
  const [tab, setTab] = useState('business');
  const { register, handleSubmit } = useForm({ values: business });
  const [notifPrefs, setNotifPrefs] = useState({ lowStock: true, payments: true, promotions: false, whatsapp: true });

  function saveBusiness(data) {
    setBusiness({ ...business, ...data });
    pushToast('Business profile updated successfully.', 'success');
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Settings</h1>
        <p className="text-sm text-ink-500 mt-1">Manage your business, profile, and application preferences.</p>
      </div>

      <div className="grid lg:grid-cols-4 gap-5">
        <Card className="p-2 h-fit lg:sticky lg:top-20">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                tab === t.id ? 'bg-brand-50 dark:bg-brand-500/10 text-brand-700 dark:text-brand-400' : 'text-ink-600 dark:text-ink-300 hover:bg-ink-100 dark:hover:bg-ink-800'
              }`}
            >
              <t.icon className="w-4 h-4" /> {t.label}
            </button>
          ))}
        </Card>

        <Card className="p-6 lg:col-span-3">
          {tab === 'business' && (
            <form className="space-y-5" onSubmit={handleSubmit(saveBusiness)}>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-500 to-violet-600 flex items-center justify-center text-white font-display font-bold text-xl">
                  {business.logoInitials}
                </div>
                <Button type="button" variant="secondary" size="sm">Change Logo</Button>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Input label="Business Name" {...register('name')} />
                <Input label="Owner Name" {...register('ownerName')} />
                <Input label="GST Number" {...register('gstNumber')} />
                <Input label="Phone" {...register('phone')} />
                <Input label="Email" type="email" {...register('email')} />
                <Input label="Address" containerClassName="sm:col-span-2" {...register('address')} />
              </div>
              <Button type="submit" icon={Save}>Save Changes</Button>
            </form>
          )}

          {tab === 'profile' && (
            <div className="space-y-5">
              <div className="flex items-center gap-4">
                <Avatar initials={currentUser.avatarInitials} size="lg" className="!w-16 !h-16 !text-xl" />
                <div>
                  <p className="font-medium text-ink-900 dark:text-white">{currentUser.name}</p>
                  <p className="text-xs text-ink-400">{currentUser.role}</p>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Input label="Full Name" defaultValue={currentUser.name} />
                <Input label="Email" defaultValue={currentUser.email} type="email" />
              </div>
              <Button icon={Save} onClick={() => pushToast('Profile updated successfully.', 'success')}>Save Changes</Button>
            </div>
          )}

          {tab === 'theme' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between p-4 rounded-xl bg-ink-50 dark:bg-ink-800/50">
                <div>
                  <p className="text-sm font-medium text-ink-800 dark:text-ink-100">Dark Mode</p>
                  <p className="text-xs text-ink-400">Switch between light and dark themes</p>
                </div>
                <ThemeToggle />
              </div>
              <p className="text-xs text-ink-400">More theming options like accent colors and density are coming soon.</p>
            </div>
          )}

          {tab === 'notifications' && (
            <div className="space-y-3">
              {[
                { key: 'lowStock', label: 'Low Stock Alerts', desc: 'Get notified when products fall below threshold' },
                { key: 'payments', label: 'Payment Reminders', desc: 'Alerts for overdue and pending payments' },
                { key: 'promotions', label: 'Promotional Updates', desc: 'Marketing tips and feature announcements' },
                { key: 'whatsapp', label: 'WhatsApp Delivery Reports', desc: 'Status updates for sent WhatsApp messages' },
              ].map((n) => (
                <div key={n.key} className="flex items-center justify-between p-4 rounded-xl bg-ink-50 dark:bg-ink-800/50">
                  <div>
                    <p className="text-sm font-medium text-ink-800 dark:text-ink-100">{n.label}</p>
                    <p className="text-xs text-ink-400">{n.desc}</p>
                  </div>
                  <button
                    onClick={() => setNotifPrefs((p) => ({ ...p, [n.key]: !p[n.key] }))}
                    className={`w-11 h-6 rounded-full relative transition-colors ${notifPrefs[n.key] ? 'bg-brand-600' : 'bg-ink-300 dark:bg-ink-700'}`}
                  >
                    <span className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${notifPrefs[n.key] ? 'translate-x-5' : ''}`} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {tab === 'backup' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-ink-50 dark:bg-ink-800/50">
                <p className="text-sm font-medium text-ink-800 dark:text-ink-100">Last Backup</p>
                <p className="text-xs text-ink-400 mt-1">Today at 3:42 AM · All data synced</p>
              </div>
              <Button icon={Database} onClick={() => pushToast('Backup started. This may take a few minutes.', 'info')}>Backup Now</Button>
            </div>
          )}

          {tab === 'language' && (
            <div className="space-y-4">
              <div className="flex flex-col gap-1.5 max-w-xs">
                <label className="text-sm font-medium text-ink-700 dark:text-ink-200">Application Language</label>
                <select defaultValue="English" className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
                  <option>English</option>
                  <option>Hindi (हिन्दी)</option>
                  <option>Marathi (मराठी)</option>
                </select>
              </div>
              <Button icon={Save} onClick={() => pushToast('Language preference saved.', 'success')}>Save Preference</Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
