import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Plus, Phone, Mail, CalendarCheck, TrendingUp, IndianRupee, ShieldCheck } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import SearchBar from '../components/ui/SearchBar';
import Badge from '../components/ui/Badge';
import Avatar from '../components/ui/Avatar';
import Modal from '../components/ui/Modal';
import { employees as seedEmployees } from '../data/employees';
import { formatCurrency, formatDate } from '../utils/format';
import { useApp } from '../context/AppContext';

const roleTone = { Admin: 'brand', Manager: 'info', Cashier: 'success', 'Inventory Staff': 'warning' };
const salaryTone = { Paid: 'success', Pending: 'danger', Processing: 'warning' };
const roles = ['Admin', 'Manager', 'Cashier', 'Inventory Staff'];

export default function Employees() {
  const { pushToast } = useApp();
  const [employees, setEmployees] = useState(seedEmployees);
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('All');
  const [addOpen, setAddOpen] = useState(false);

  const filtered = useMemo(
    () => employees.filter((e) => e.name.toLowerCase().includes(search.toLowerCase()) && (role === 'All' || e.role === role)),
    [employees, search, role]
  );

  function handleAdd(data) {
    const newEmp = {
      id: `EMP${String(employees.length + 1).padStart(3, '0')}`,
      ...data,
      avatarInitials: data.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase(),
      permissions: data.role === 'Admin' ? ['Full Access'] : data.role === 'Manager' ? ['View Reports', 'Billing'] : ['Billing'],
      joinedDate: new Date().toISOString(),
      attendanceThisMonth: 0,
      totalWorkingDays: 26,
      performanceScore: 80,
      salaryStatus: 'Pending',
      monthlySalary: Number(data.monthlySalary) || 15000,
    };
    setEmployees((prev) => [newEmp, ...prev]);
    pushToast(`${data.name} added to the team.`, 'success');
    setAddOpen(false);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Employee Management</h1>
          <p className="text-sm text-ink-500 mt-1">{employees.length} team members across {roles.length} roles</p>
        </div>
        <Button icon={Plus} onClick={() => setAddOpen(true)}>Add Employee</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchBar value={search} onChange={setSearch} placeholder="Search employees..." className="sm:max-w-xs" />
        <select value={role} onChange={(e) => setRole(e.target.value)} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
          <option>All</option>
          {roles.map((r) => <option key={r}>{r}</option>)}
        </select>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((e) => (
          <Card key={e.id} hover className="p-5">
            <div className="flex items-center gap-3">
              <Avatar initials={e.avatarInitials} size="lg" />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-ink-900 dark:text-white text-sm truncate">{e.name}</p>
                <Badge tone={roleTone[e.role]} className="mt-1">{e.role}</Badge>
              </div>
            </div>

            <div className="mt-4 space-y-1.5 text-xs text-ink-500">
              <p className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" /> {e.phone}</p>
              <p className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" /> {e.email}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="p-2.5 rounded-lg bg-ink-50 dark:bg-ink-800/50">
                <p className="flex items-center gap-1 text-[11px] text-ink-400"><CalendarCheck className="w-3 h-3" /> Attendance</p>
                <p className="text-sm font-semibold text-ink-800 dark:text-ink-100">{e.attendanceThisMonth}/{e.totalWorkingDays} days</p>
              </div>
              <div className="p-2.5 rounded-lg bg-ink-50 dark:bg-ink-800/50">
                <p className="flex items-center gap-1 text-[11px] text-ink-400"><TrendingUp className="w-3 h-3" /> Performance</p>
                <p className="text-sm font-semibold text-ink-800 dark:text-ink-100">{e.performanceScore}%</p>
              </div>
            </div>

            <div className="flex items-center justify-between mt-4 pt-4 border-t border-ink-100 dark:border-ink-800">
              <div className="flex items-center gap-1 text-xs text-ink-500">
                <IndianRupee className="w-3.5 h-3.5" />
                {e.monthlySalary ? formatCurrency(e.monthlySalary) : '—'}
              </div>
              <Badge tone={salaryTone[e.salaryStatus]}>{e.salaryStatus}</Badge>
            </div>

            <div className="mt-3 flex items-center gap-1.5 flex-wrap">
              {e.permissions.slice(0, 2).map((p) => (
                <span key={p} className="flex items-center gap-1 text-[10px] bg-ink-100 dark:bg-ink-800 text-ink-500 px-2 py-1 rounded-full">
                  <ShieldCheck className="w-2.5 h-2.5" /> {p}
                </span>
              ))}
              {e.permissions.length > 2 && (
                <span className="text-[10px] text-ink-400">+{e.permissions.length - 2} more</span>
              )}
            </div>
          </Card>
        ))}
      </div>

      <AddEmployeeModal open={addOpen} onClose={() => setAddOpen(false)} onSave={handleAdd} />
    </div>
  );
}

function AddEmployeeModal({ open, onClose, onSave }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm({ defaultValues: { role: 'Cashier' } });
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add New Employee"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit((data) => { onSave(data); reset(); })}>Add Employee</Button>
        </>
      }
    >
      <form className="grid sm:grid-cols-2 gap-4">
        <Input label="Full Name" containerClassName="sm:col-span-2" {...register('name', { required: 'Required' })} error={errors.name?.message} />
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink-700 dark:text-ink-200">Role</label>
          <select {...register('role')} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            {roles.map((r) => <option key={r}>{r}</option>)}
          </select>
        </div>
        <Input label="Monthly Salary (₹)" type="number" {...register('monthlySalary')} />
        <Input label="Phone Number" {...register('phone', { required: 'Required' })} error={errors.phone?.message} />
        <Input label="Email" type="email" {...register('email')} />
      </form>
    </Modal>
  );
}
