import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Plus, Phone, Mail, Star, Wallet, Gift, StickyNote, Users } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import SearchBar from '../components/ui/SearchBar';
import Badge from '../components/ui/Badge';
import Avatar from '../components/ui/Avatar';
import Modal from '../components/ui/Modal';
import EmptyState from '../components/ui/EmptyState';
import Pagination from '../components/ui/Pagination';
import { customers as seedCustomers } from '../data/customers';
import { formatCurrency, formatDate } from '../utils/format';
import { useApp } from '../context/AppContext';

const PAGE_SIZE = 9;
const tierTone = { Bronze: 'neutral', Silver: 'info', Gold: 'warning', Platinum: 'brand' };

export default function Customers() {
  const { pushToast } = useApp();
  const [customers, setCustomers] = useState(seedCustomers);
  const [search, setSearch] = useState('');
  const [tier, setTier] = useState('All');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);
  const [addOpen, setAddOpen] = useState(false);

  const filtered = useMemo(
    () =>
      customers.filter(
        (c) =>
          (c.name.toLowerCase().includes(search.toLowerCase()) || c.phone.includes(search)) &&
          (tier === 'All' || c.tier === tier)
      ),
    [customers, search, tier]
  );
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function handleAdd(data) {
    const newCust = {
      id: `CUST${String(customers.length + 1).padStart(4, '0')}`,
      ...data,
      avatarInitials: data.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase(),
      tier: 'Bronze',
      totalPurchases: 0,
      totalSpend: 0,
      outstanding: 0,
      loyaltyPoints: 0,
      joinedDate: new Date().toISOString(),
      lastPurchaseDate: new Date().toISOString(),
      purchaseHistory: [],
    };
    setCustomers((prev) => [newCust, ...prev]);
    pushToast(`${data.name} added as a new customer.`, 'success');
    setAddOpen(false);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Customers</h1>
          <p className="text-sm text-ink-500 mt-1">{customers.length} customers · {customers.filter((c) => c.outstanding > 0).length} with outstanding dues</p>
        </div>
        <Button icon={Plus} onClick={() => setAddOpen(true)}>Add Customer</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchBar value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="Search by name or phone..." className="sm:max-w-xs" />
        <select value={tier} onChange={(e) => { setTier(e.target.value); setPage(1); }} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
          <option>All</option>
          {['Bronze', 'Silver', 'Gold', 'Platinum'].map((t) => <option key={t}>{t}</option>)}
        </select>
      </div>

      {paged.length === 0 ? (
        <EmptyState icon={Users} title="No customers found" description="Try a different search or filter." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {paged.map((c) => (
            <Card key={c.id} hover className="p-5 cursor-pointer" onClick={() => setSelected(c)}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Avatar initials={c.avatarInitials} size="lg" />
                  <div>
                    <p className="font-medium text-ink-900 dark:text-white text-sm">{c.name}</p>
                    <p className="text-xs text-ink-400">{c.phone}</p>
                  </div>
                </div>
                <Badge tone={tierTone[c.tier]}>{c.tier}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
                <div>
                  <p className="text-ink-400">Total Spend</p>
                  <p className="font-semibold text-ink-800 dark:text-ink-100">{formatCurrency(c.totalSpend, { compact: true })}</p>
                </div>
                <div>
                  <p className="text-ink-400">Orders</p>
                  <p className="font-semibold text-ink-800 dark:text-ink-100">{c.totalPurchases}</p>
                </div>
                <div>
                  <p className="text-ink-400">Loyalty Points</p>
                  <p className="font-semibold text-ink-800 dark:text-ink-100">{c.loyaltyPoints}</p>
                </div>
                <div>
                  <p className="text-ink-400">Outstanding</p>
                  <p className={`font-semibold ${c.outstanding > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {c.outstanding > 0 ? formatCurrency(c.outstanding) : 'Clear'}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Pagination page={page} totalPages={totalPages} onPageChange={setPage} totalItems={filtered.length} pageSize={PAGE_SIZE} />

      {/* Customer detail modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title="Customer Details" size="lg">
        {selected && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <Avatar initials={selected.avatarInitials} size="lg" className="!w-14 !h-14 !text-lg" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-display font-semibold text-lg text-ink-900 dark:text-white">{selected.name}</p>
                  <Badge tone={tierTone[selected.tier]}>{selected.tier}</Badge>
                </div>
                <div className="flex items-center gap-4 text-xs text-ink-500 mt-1">
                  <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {selected.phone}</span>
                  <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {selected.email}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: 'Total Spend', value: formatCurrency(selected.totalSpend), icon: Wallet },
                { label: 'Orders', value: selected.totalPurchases, icon: Star },
                { label: 'Loyalty Points', value: selected.loyaltyPoints, icon: Gift },
                { label: 'Outstanding', value: selected.outstanding > 0 ? formatCurrency(selected.outstanding) : '₹0', icon: Wallet },
              ].map((s) => (
                <div key={s.label} className="p-3 rounded-xl bg-ink-50 dark:bg-ink-800/50 text-center">
                  <s.icon className="w-4 h-4 mx-auto text-brand-500 mb-1" />
                  <p className="text-sm font-semibold text-ink-900 dark:text-white">{s.value}</p>
                  <p className="text-[11px] text-ink-400">{s.label}</p>
                </div>
              ))}
            </div>

            <div>
              <p className="text-sm font-semibold text-ink-800 dark:text-ink-100 mb-2">Purchase History</p>
              {selected.purchaseHistory.length === 0 ? (
                <p className="text-xs text-ink-400">No purchases yet.</p>
              ) : (
                <div className="space-y-2">
                  {selected.purchaseHistory.map((h) => (
                    <div key={h.invoiceId} className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-ink-50 dark:bg-ink-800/50">
                      <span className="font-mono text-ink-500">{h.invoiceId}</span>
                      <span className="text-ink-500">{formatDate(h.date)}</span>
                      <span className="text-ink-500">{h.items} items</span>
                      <span className="font-semibold text-ink-800 dark:text-ink-100">{formatCurrency(h.amount)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {selected.notes && (
              <div className="flex gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-300 text-xs">
                <StickyNote className="w-4 h-4 shrink-0 mt-0.5" />
                {selected.notes}
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Add customer modal */}
      <AddCustomerModal open={addOpen} onClose={() => setAddOpen(false)} onSave={handleAdd} />
    </div>
  );
}

function AddCustomerModal({ open, onClose, onSave }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add New Customer"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit((data) => { onSave(data); reset(); })}>Add Customer</Button>
        </>
      }
    >
      <form className="grid sm:grid-cols-2 gap-4">
        <Input label="Full Name" containerClassName="sm:col-span-2" {...register('name', { required: 'Required' })} error={errors.name?.message} />
        <Input label="Phone Number" {...register('phone', { required: 'Required' })} error={errors.phone?.message} />
        <Input label="Email" type="email" {...register('email')} />
        <Input label="Notes" containerClassName="sm:col-span-2" {...register('notes')} placeholder="Optional preferences or notes" />
      </form>
    </Modal>
  );
}
