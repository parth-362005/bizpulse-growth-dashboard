import { useMemo, useState } from 'react';
import { Plus, Upload, Download, Pencil, Trash2, Boxes, AlertTriangle } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import SearchBar from '../components/ui/SearchBar';
import Badge from '../components/ui/Badge';
import Table, { Tr, Td } from '../components/ui/Table';
import Pagination from '../components/ui/Pagination';
import Modal from '../components/ui/Modal';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import EmptyState from '../components/ui/EmptyState';
import { useForm } from 'react-hook-form';
import Input from '../components/ui/Input';
import { products as seedProducts, categories, suppliers } from '../data/products';
import { formatCurrency, formatDate } from '../utils/format';
import { useApp } from '../context/AppContext';

const PAGE_SIZE = 8;

export default function Inventory() {
  const { pushToast } = useApp();
  const [products, setProducts] = useState(seedProducts);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [stockFilter, setStockFilter] = useState('All');
  const [supplierFilter, setSupplierFilter] = useState('All');
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === 'All' || p.category === category;
      const matchesSupplier = supplierFilter === 'All' || p.supplier === supplierFilter;
      const matchesStock =
        stockFilter === 'All' ||
        (stockFilter === 'Low Stock' && p.isLowStock) ||
        (stockFilter === 'In Stock' && p.stock > p.lowStockThreshold) ||
        (stockFilter === 'Out of Stock' && p.stock === 0);
      return matchesSearch && matchesCategory && matchesSupplier && matchesStock;
    });
  }, [products, search, category, stockFilter, supplierFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function openAdd() {
    setEditingProduct(null);
    setModalOpen(true);
  }
  function openEdit(p) {
    setEditingProduct(p);
    setModalOpen(true);
  }
  function handleSave(data) {
    if (editingProduct) {
      setProducts((prev) => prev.map((p) => (p.id === editingProduct.id ? { ...p, ...data, sellingPrice: Number(data.sellingPrice), purchasePrice: Number(data.purchasePrice), stock: Number(data.stock) } : p)));
      pushToast(`${data.name} updated successfully.`, 'success');
    } else {
      const newProduct = {
        id: `PRD${String(products.length + 1).padStart(4, '0')}`,
        sku: `SKU-NEW-${1000 + products.length}`,
        ...data,
        purchasePrice: Number(data.purchasePrice),
        sellingPrice: Number(data.sellingPrice),
        stock: Number(data.stock),
        lowStockThreshold: 15,
        isLowStock: Number(data.stock) <= 15,
        expiryDate: new Date().toISOString(),
        gstRate: 12,
        unit: 'pcs',
      };
      setProducts((prev) => [newProduct, ...prev]);
      pushToast(`${data.name} added to inventory.`, 'success');
    }
    setModalOpen(false);
  }
  function handleDelete() {
    setProducts((prev) => prev.filter((p) => p.id !== deleteTarget.id));
    pushToast(`${deleteTarget.name} removed from inventory.`, 'info');
    setDeleteTarget(null);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Inventory</h1>
          <p className="text-sm text-ink-500 mt-1">{products.length} products across {categories.length} categories</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" icon={Upload} onClick={() => pushToast('CSV import started (demo).', 'info')}>Import CSV</Button>
          <Button variant="secondary" icon={Download} onClick={() => pushToast('Exporting inventory to CSV...', 'info')}>Export CSV</Button>
          <Button icon={Plus} onClick={openAdd}>Add Product</Button>
        </div>
      </div>

      <Card className="p-5">
        <div className="flex flex-col lg:flex-row gap-3 mb-5">
          <SearchBar value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="Search by product name or SKU..." className="lg:max-w-xs" />
          <select value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            <option>All</option>
            {categories.map((c) => <option key={c}>{c}</option>)}
          </select>
          <select value={stockFilter} onChange={(e) => { setStockFilter(e.target.value); setPage(1); }} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            <option>All</option>
            <option>In Stock</option>
            <option>Low Stock</option>
            <option>Out of Stock</option>
          </select>
          <select value={supplierFilter} onChange={(e) => { setSupplierFilter(e.target.value); setPage(1); }} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            <option>All</option>
            {suppliers.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>

        {paged.length === 0 ? (
          <EmptyState icon={Boxes} title="No products found" description="Try adjusting your filters or search term." />
        ) : (
          <>
            <Table columns={['Product', 'SKU', 'Category', 'Purchase Price', 'Selling Price', 'Stock', 'Supplier', 'Expiry', 'Actions']}>
              {paged.map((p) => (
                <Tr key={p.id}>
                  <Td>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-ink-100 dark:bg-ink-800 flex items-center justify-center shrink-0">
                        <Boxes className="w-4 h-4 text-ink-400" />
                      </div>
                      <span className="font-medium text-ink-900 dark:text-white">{p.name}</span>
                    </div>
                  </Td>
                  <Td className="font-mono text-xs">{p.sku}</Td>
                  <Td><Badge tone="neutral">{p.category}</Badge></Td>
                  <Td>{formatCurrency(p.purchasePrice)}</Td>
                  <Td className="font-medium">{formatCurrency(p.sellingPrice)}</Td>
                  <Td>
                    <div className="flex items-center gap-1.5">
                      {p.stock}
                      {p.isLowStock && (
                        <span title="Low stock"><AlertTriangle className="w-3.5 h-3.5 text-amber-500" /></span>
                      )}
                    </div>
                  </Td>
                  <Td className="max-w-[160px] truncate text-xs">{p.supplier}</Td>
                  <Td className="text-xs">{formatDate(p.expiryDate)}</Td>
                  <Td>
                    <div className="flex items-center gap-1">
                      <button onClick={() => openEdit(p)} className="p-1.5 rounded-lg hover:bg-ink-100 dark:hover:bg-ink-800 text-ink-500">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button onClick={() => setDeleteTarget(p)} className="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-500/10 text-rose-500">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </Td>
                </Tr>
              ))}
            </Table>
            <Pagination page={page} totalPages={totalPages} onPageChange={setPage} totalItems={filtered.length} pageSize={PAGE_SIZE} />
          </>
        )}
      </Card>

      <ProductModal open={modalOpen} onClose={() => setModalOpen(false)} onSave={handleSave} product={editingProduct} />
      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete product?"
        description={`This will permanently remove "${deleteTarget?.name}" from your inventory. This action cannot be undone.`}
      />
    </div>
  );
}

function ProductModal({ open, onClose, onSave, product }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    values: product
      ? { ...product }
      : { name: '', category: categories[0], purchasePrice: '', sellingPrice: '', stock: '', supplier: suppliers[0] },
  });

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={product ? 'Edit Product' : 'Add New Product'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit((data) => { onSave(data); reset(); })}>{product ? 'Save Changes' : 'Add Product'}</Button>
        </>
      }
    >
      <form className="grid sm:grid-cols-2 gap-4">
        <Input label="Product Name" containerClassName="sm:col-span-2" {...register('name', { required: 'Required' })} error={errors.name?.message} />
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink-700 dark:text-ink-200">Category</label>
          <select {...register('category')} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            {categories.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink-700 dark:text-ink-200">Supplier</label>
          <select {...register('supplier')} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
            {suppliers.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <Input label="Purchase Price (₹)" type="number" {...register('purchasePrice', { required: 'Required' })} error={errors.purchasePrice?.message} />
        <Input label="Selling Price (₹)" type="number" {...register('sellingPrice', { required: 'Required' })} error={errors.sellingPrice?.message} />
        <Input label="Stock Quantity" type="number" {...register('stock', { required: 'Required' })} error={errors.stock?.message} />
      </form>
    </Modal>
  );
}
