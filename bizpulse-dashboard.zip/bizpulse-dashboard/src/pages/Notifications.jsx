import { useMemo, useState } from 'react';
import { MessageCircle, Send, Check, CheckCheck, Clock, X } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import SearchBar from '../components/ui/SearchBar';
import Modal from '../components/ui/Modal';
import { whatsappNotifications } from '../data/notifications';
import { customers } from '../data/customers';
import { formatDateTime } from '../utils/format';
import { useApp } from '../context/AppContext';

const typeTone = { 'Invoice Sent': 'brand', 'Payment Reminder': 'warning', Promotion: 'info', 'Order Confirmation': 'success' };
const statusIcon = { Delivered: CheckCheck, Read: CheckCheck, Sent: Check, Failed: X };
const statusTone = { Delivered: 'info', Read: 'success', Sent: 'neutral', Failed: 'danger' };

export default function Notifications() {
  const { pushToast } = useApp();
  const [search, setSearch] = useState('');
  const [type, setType] = useState('All');
  const [composeOpen, setComposeOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [message, setMessage] = useState('Hi {name}, we have a special offer waiting for you at Shree Ganesh General Store!');
  const [recipient, setRecipient] = useState(customers[0]?.name || '');

  const filtered = useMemo(
    () =>
      whatsappNotifications.filter(
        (n) => n.customer.toLowerCase().includes(search.toLowerCase()) && (type === 'All' || n.type === type)
      ),
    [search, type]
  );

  function handleSend() {
    pushToast(`Message sent to ${recipient} via WhatsApp.`, 'success');
    setComposeOpen(false);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">WhatsApp Notifications</h1>
          <p className="text-sm text-ink-500 mt-1">{whatsappNotifications.length} messages sent · invoices, reminders & promotions</p>
        </div>
        <Button icon={Send} onClick={() => setComposeOpen(true)}>New Message</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchBar value={search} onChange={setSearch} placeholder="Search by customer name..." className="sm:max-w-xs" />
        <select value={type} onChange={(e) => setType(e.target.value)} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
          <option>All</option>
          {['Invoice Sent', 'Payment Reminder', 'Promotion', 'Order Confirmation'].map((t) => <option key={t}>{t}</option>)}
        </select>
      </div>

      <div className="grid gap-3">
        {filtered.map((n) => {
          const StatusIcon = statusIcon[n.status];
          return (
            <Card key={n.id} hover className="p-4 cursor-pointer" onClick={() => setSelected(n)}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-medium text-ink-900 dark:text-white">{n.customer}</p>
                    <Badge tone={typeTone[n.type]}>{n.type}</Badge>
                  </div>
                  <p className="text-xs text-ink-500 mt-1 truncate">{n.message}</p>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <Badge tone={statusTone[n.status]}>
                    <StatusIcon className="w-3 h-3" /> {n.status}
                  </Badge>
                  <span className="text-[11px] text-ink-400">{formatDateTime(n.date)}</span>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Detail modal with status timeline */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title="Message Details">
        {selected && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-ink-900 dark:text-white">{selected.customer}</p>
                <p className="text-xs text-ink-400">{selected.phone}</p>
              </div>
              <Badge tone={typeTone[selected.type]}>{selected.type}</Badge>
            </div>
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/5 border border-emerald-100 dark:border-emerald-900 text-sm text-ink-700 dark:text-ink-200">
              {selected.message}
            </div>
            <div>
              <p className="text-xs font-medium text-ink-500 mb-3">Status Timeline</p>
              <div className="flex items-center">
                {selected.timeline.map((step, i) => (
                  <div key={step.step} className="flex items-center flex-1 last:flex-none">
                    <div className="flex flex-col items-center gap-1.5">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center ${step.done ? 'bg-emerald-500 text-white' : 'bg-ink-100 dark:bg-ink-800 text-ink-400'}`}>
                        {step.done ? <Check className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                      </div>
                      <span className="text-[10px] text-ink-500">{step.step}</span>
                    </div>
                    {i < selected.timeline.length - 1 && (
                      <div className={`flex-1 h-0.5 mx-1 ${selected.timeline[i + 1].done ? 'bg-emerald-500' : 'bg-ink-200 dark:bg-ink-800'}`} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Compose modal */}
      <Modal
        open={composeOpen}
        onClose={() => setComposeOpen(false)}
        title="Send WhatsApp Message"
        footer={
          <>
            <Button variant="secondary" onClick={() => setComposeOpen(false)}>Cancel</Button>
            <Button icon={Send} onClick={handleSend}>Send Message</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink-700 dark:text-ink-200">Recipient</label>
            <select value={recipient} onChange={(e) => setRecipient(e.target.value)} className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500">
              {customers.slice(0, 12).map((c) => <option key={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink-700 dark:text-ink-200">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="bg-white dark:bg-ink-900 border border-ink-200 dark:border-ink-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-500 resize-none"
            />
          </div>
          <div className="p-3 rounded-xl bg-ink-50 dark:bg-ink-800/50">
            <p className="text-xs text-ink-400 mb-1">Preview</p>
            <p className="text-sm text-ink-700 dark:text-ink-200">{message.replace('{name}', recipient.split(' ')[0])}</p>
          </div>
        </div>
      </Modal>
    </div>
  );
}
