import {
  ComposedChart, Line, Area, BarChart, Bar, RadialBarChart, RadialBar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PolarAngleAxis,
} from 'recharts';
import {
  Sparkles, TrendingUp, ShoppingBag, PackageX, Target,
  AlertTriangle, CalendarClock, PackageSearch,
} from 'lucide-react';
import KpiCard from '../components/dashboard/KpiCard';
import ChartCard from '../components/dashboard/ChartCard';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Table, { Tr, Td } from '../components/ui/Table';
import { forecastGraph, seasonalSales, demandPrediction, aiInsights, predictionKpis } from '../data/notifications';
import { formatCurrency } from '../utils/format';

const insightIcons = { TrendingUp, AlertTriangle, Sparkles, CalendarClock, PackageSearch };
const insightTone = {
  positive: 'from-emerald-500/20 to-emerald-500/5 border-emerald-400/30 text-emerald-600 dark:text-emerald-400',
  warning: 'from-amber-500/20 to-amber-500/5 border-amber-400/30 text-amber-600 dark:text-amber-400',
  info: 'from-brand-500/20 to-brand-500/5 border-brand-400/30 text-brand-600 dark:text-brand-400',
};

export default function Prediction() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-brand-500 to-fuchsia-500 flex items-center justify-center shadow-glow animate-glow-pulse">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">AI Sales Prediction</h1>
          <p className="text-sm text-ink-500 mt-1">Machine learning forecasts based on your last 12 months of sales data.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Expected Revenue (30d)" value={formatCurrency(predictionKpis.expectedRevenue, { compact: true })} change={predictionKpis.expectedRevenueChange} icon={TrendingUp} tone="brand" />
        <KpiCard label="Expected Sales (units)" value={predictionKpis.expectedSales} change={predictionKpis.expectedSalesChange} icon={ShoppingBag} tone="sky" />
        <KpiCard label="Restock Alerts" value={predictionKpis.restockAlerts} icon={PackageX} tone="rose" />
        <KpiCard label="Forecast Accuracy" value={`${predictionKpis.demandForecastAccuracy}%`} icon={Target} tone="emerald" />
      </div>

      {/* AI Insight Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {aiInsights.map((insight, i) => {
          const Icon = insightIcons[insight.icon] || Sparkles;
          return (
            <Card key={i} className={`p-4 bg-gradient-to-br ${insightTone[insight.tone]} border relative overflow-hidden`}>
              <div className="flex gap-3 items-start">
                <div className="w-9 h-9 rounded-xl bg-white/60 dark:bg-white/10 backdrop-blur flex items-center justify-center shrink-0 shadow-soft">
                  <Icon className="w-4.5 h-4.5" />
                </div>
                <p className="text-sm text-ink-700 dark:text-ink-200 leading-snug pt-1">{insight.text}</p>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <ChartCard title="Forecast Graph" subtitle="Actual vs AI-predicted sales, next 14 days" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={280}>
            <ComposedChart data={forecastGraph}>
              <defs>
                <linearGradient id="predGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#d946ef" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#d946ef" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip formatter={(v) => (v ? formatCurrency(v) : '—')} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Area type="monotone" dataKey="predicted" stroke="#d946ef" strokeWidth={2} fill="url(#predGrad)" strokeDasharray="5 4" />
              <Line type="monotone" dataKey="actual" stroke="#6366f1" strokeWidth={2.5} dot={{ r: 3 }} />
            </ComposedChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-2 text-xs text-ink-500">
            <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-brand-500 inline-block" /> Actual</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-fuchsia-500 inline-block border-dashed" /> AI Predicted</span>
          </div>
        </ChartCard>

        <ChartCard title="Seasonal Sales Growth" subtitle="Predicted uplift by season">
          <ResponsiveContainer width="100%" height={280}>
            <RadialBarChart innerRadius="20%" outerRadius="100%" data={seasonalSales} startAngle={90} endAngle={-270}>
              <PolarAngleAxis type="number" domain={[0, 45]} angleAxisId={0} tick={false} />
              <RadialBar background dataKey="growth" cornerRadius={8} fill="#8b5cf6" />
              <Tooltip formatter={(v) => `+${v}%`} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            </RadialBarChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-1.5 -mt-4 text-[11px] text-ink-500">
            {seasonalSales.map((s) => (
              <div key={s.season} className="flex justify-between">
                <span>{s.season}</span>
                <span className="font-medium text-ink-700 dark:text-ink-200">+{s.growth}%</span>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      <Card className="p-5">
        <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-4">Demand Prediction & Restock Alerts</h3>
        <Table columns={['Product', 'Current Stock', 'Predicted Demand', 'Restock Within']}>
          {demandPrediction.map((d) => (
            <Tr key={d.product}>
              <Td className="font-medium">{d.product}</Td>
              <Td>{d.currentStock}</Td>
              <Td>{d.predictedDemand} units</Td>
              <Td>
                <Badge tone={d.restockIn <= 3 ? 'danger' : d.restockIn <= 5 ? 'warning' : 'success'}>
                  {d.restockIn} day{d.restockIn > 1 ? 's' : ''}
                </Badge>
              </Td>
            </Tr>
          ))}
        </Table>
      </Card>
    </div>
  );
}
