import { useMemo, useState } from 'react';
import { Plus, Minus, Trash2, Wallet, CreditCard, Smartphone, Receipt, Printer, ShoppingCart } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import SearchBar from '../components/ui/SearchBar';
import Badge from '../components/ui/Badge';
import EmptyState from '../components/ui/EmptyState';
import Modal from '../components/ui/Modal';
import { products } from '../data/products';
import { todayStats, weeklySales } from '../data/sales';
import { formatCurrency } from '../utils/format';
import { useApp } from '../context/AppContext';

const paymentMethods = [
  { id: 'Cash', label: 'Cash', icon: Wallet },
  { id: 'Card', label: 'Card', icon: CreditCard },
  { id: 'UPI', label: 'UPI', icon: Smartphone },
];

export default function Sales() {
  const { pushToast } = useApp();
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [discount, setDiscount] = useState(0);
  const [payment, setPayment] = useState('Cash');
  const [invoiceOpen, setInvoiceOpen] = useState(false);
  const [lastSale, setLastSale] = useState(null);

  const filteredProducts = useMemo(
    () => products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase())).slice(0, 24),
    [search]
  );

  function addToCart(product) {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) {
        return prev.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...product, qty: 1 }];
    });
  }
  function updateQty(id, delta) {
    setCart((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i))
        .filter((i) => i.qty > 0)
    );
  }
  function removeItem(id) {
    setCart((prev) => prev.filter((i) => i.id !== id));
  }

  const subtotal = cart.reduce((s, i) => s + i.sellingPrice * i.qty, 0);
  const gst = cart.reduce((s, i) => s + (i.sellingPrice * i.qty * i.gstRate) / 100, 0);
  const discountAmt = Math.round((subtotal * discount) / 100);
  const grandTotal = Math.round(subtotal + gst - discountAmt);

  function generateInvoice() {
    if (cart.length === 0) return;
    setLastSale({ items: cart, subtotal, gst, discountAmt, grandTotal, payment, id: `INV${Math.floor(2400 + Math.random() * 90)}`, date: new Date() });
    setInvoiceOpen(true);
  }
  function completeSale() {
    pushToast(`Invoice generated · ${formatCurrency(grandTotal)} via ${payment}`, 'success');
    setCart([]);
    setDiscount(0);
    setInvoiceOpen(false);
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Sales — POS Billing</h1>
        <p className="text-sm text-ink-500 mt-1">Search products, build a cart, and generate a GST-ready invoice.</p>
      </div>

      <div className="grid xl:grid-cols-3 gap-5">
        {/* Product search & grid */}
        <div className="xl:col-span-2 space-y-4">
          <Card className="p-5">
            <SearchBar value={search} onChange={setSearch} placeholder="Search products to add to cart..." className="mb-4" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[520px] overflow-y-auto scrollbar-thin pr-1">
              {filteredProducts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => addToCart(p)}
                  className="text-left p-3.5 rounded-xl border border-ink-100 dark:border-ink-800 hover:border-brand-300 hover:shadow-soft transition-all bg-white dark:bg-ink-900"
                >
                  <p className="text-sm font-medium text-ink-900 dark:text-white line-clamp-1">{p.name}</p>
                  <p className="text-xs text-ink-400 mt-0.5">{p.category}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm font-semibold text-brand-600">{formatCurrency(p.sellingPrice)}</span>
                    <span className={`text-[11px] ${p.stock === 0 ? 'text-rose-500' : 'text-ink-400'}`}>{p.stock === 0 ? 'Out of stock' : `${p.stock} in stock`}</span>
                  </div>
                </button>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-3">Today's Sales Summary</h3>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-ink-500">Total Sales</p>
                <p className="text-lg font-bold text-ink-900 dark:text-white">{formatCurrency(todayStats.todaySales)}</p>
              </div>
              <div>
                <p className="text-xs text-ink-500">Orders</p>
                <p className="text-lg font-bold text-ink-900 dark:text-white">{todayStats.todayOrders}</p>
              </div>
              <div>
                <p className="text-xs text-ink-500">Avg. Order Value</p>
                <p className="text-lg font-bold text-ink-900 dark:text-white">{formatCurrency(Math.round(todayStats.todaySales / todayStats.todayOrders))}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Cart */}
        <Card className="p-5 h-fit xl:sticky xl:top-20">
          <div className="flex items-center gap-2 mb-4">
            <ShoppingCart className="w-4 h-4 text-brand-600" />
            <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white">Cart ({cart.length})</h3>
          </div>

          {cart.length === 0 ? (
            <EmptyState icon={ShoppingCart} title="Cart is empty" description="Click on a product to add it to the cart." />
          ) : (
            <div className="space-y-3 max-h-72 overflow-y-auto scrollbar-thin mb-4">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-ink-800 dark:text-ink-100 truncate">{item.name}</p>
                    <p className="text-xs text-ink-400">{formatCurrency(item.sellingPrice)} × {item.qty}</p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button onClick={() => updateQty(item.id, -1)} className="w-6 h-6 rounded-md border border-ink-200 dark:border-ink-700 flex items-center justify-center hover:bg-ink-100 dark:hover:bg-ink-800">
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-5 text-center text-xs font-medium">{item.qty}</span>
                    <button onClick={() => updateQty(item.id, 1)} className="w-6 h-6 rounded-md border border-ink-200 dark:border-ink-700 flex items-center justify-center hover:bg-ink-100 dark:hover:bg-ink-800">
                      <Plus className="w-3 h-3" />
                    </button>
                    <button onClick={() => removeItem(item.id)} className="w-6 h-6 rounded-md flex items-center justify-center text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 ml-1">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="border-t border-ink-100 dark:border-ink-800 pt-4 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-500">Subtotal</span>
              <span className="font-medium">{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-500">GST</span>
              <span className="font-medium">{formatCurrency(Math.round(gst))}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-500">Discount</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  value={discount}
                  onChange={(e) => setDiscount(Math.min(50, Math.max(0, Number(e.target.value))))}
                  className="w-14 bg-ink-100 dark:bg-ink-800 rounded-lg px-2 py-1 text-xs text-right outline-none"
                />
                <span className="text-xs text-ink-400">%</span>
              </div>
            </div>
            <div className="flex items-center justify-between text-base font-bold pt-2 border-t border-ink-100 dark:border-ink-800">
              <span>Grand Total</span>
              <span className="text-brand-600">{formatCurrency(grandTotal)}</span>
            </div>
          </div>

          <div className="mt-4">
            <p className="text-xs font-medium text-ink-500 mb-2">Payment Method</p>
            <div className="grid grid-cols-3 gap-2">
              {paymentMethods.map((pm) => (
                <button
                  key={pm.id}
                  onClick={() => setPayment(pm.id)}
                  className={`flex flex-col items-center gap-1 py-2.5 rounded-xl border text-xs font-medium transition-all ${
                    payment === pm.id
                      ? 'border-brand-500 bg-brand-50 dark:bg-brand-500/10 text-brand-700 dark:text-brand-400'
                      : 'border-ink-200 dark:border-ink-700 text-ink-500 hover:bg-ink-50 dark:hover:bg-ink-800'
                  }`}
                >
                  <pm.icon className="w-4 h-4" />
                  {pm.label}
                </button>
              ))}
            </div>
          </div>

          <Button className="w-full mt-5" size="lg" icon={Receipt} disabled={cart.length === 0} onClick={generateInvoice}>
            Generate Invoice
          </Button>
        </Card>
      </div>

      <Modal
        open={invoiceOpen}
        onClose={() => setInvoiceOpen(false)}
        title="Invoice Preview"
        footer={
          <>
            <Button variant="secondary" icon={Printer} onClick={() => pushToast('Sending to printer...', 'info')}>Print</Button>
            <Button onClick={completeSale}>Confirm & Complete Sale</Button>
          </>
        }
      >
        {lastSale && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-display font-bold text-ink-900 dark:text-white">Shree Ganesh General Store</p>
                <p className="text-xs text-ink-400">GSTIN: 27ABCDE1234F1Z5</p>
              </div>
              <Badge tone="brand">{lastSale.id}</Badge>
            </div>
            <div className="border-t border-dashed border-ink-200 dark:border-ink-700 pt-3 space-y-1.5">
              {lastSale.items.map((item) => (
                <div key={item.id} className="flex justify-between text-xs">
                  <span className="text-ink-600 dark:text-ink-300">{item.name} × {item.qty}</span>
                  <span className="font-medium">{formatCurrency(item.sellingPrice * item.qty)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-dashed border-ink-200 dark:border-ink-700 pt-3 space-y-1.5 text-xs">
              <div className="flex justify-between"><span className="text-ink-500">Subtotal</span><span>{formatCurrency(lastSale.subtotal)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">GST</span><span>{formatCurrency(Math.round(lastSale.gst))}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">Discount</span><span>-{formatCurrency(lastSale.discountAmt)}</span></div>
              <div className="flex justify-between text-sm font-bold pt-2 border-t border-ink-100 dark:border-ink-800"><span>Total</span><span>{formatCurrency(lastSale.grandTotal)}</span></div>
              <div className="flex justify-between pt-1"><span className="text-ink-500">Payment</span><span>{lastSale.payment}</span></div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
