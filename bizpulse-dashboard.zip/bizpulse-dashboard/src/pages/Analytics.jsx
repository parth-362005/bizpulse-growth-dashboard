import { Fragment } from 'react';
import {
  AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { IndianRupee, TrendingDown, TrendingUp, PieChart as PieIcon, Percent } from 'lucide-react';
import KpiCard from '../components/dashboard/KpiCard';
import ChartCard from '../components/dashboard/ChartCard';
import Card from '../components/ui/Card';
import Table, { Tr, Td } from '../components/ui/Table';
import {
  monthlyRevenue, profitTrend, expenseBreakdown, topProducts, topCustomers, profitHeatmap,
} from '../data/sales';
import { formatCurrency } from '../utils/format';

const PIE_COLORS = ['#6366f1', '#8b5cf6', '#d946ef', '#f59e0b', '#10b981', '#0ea5e9'];

const latest = monthlyRevenue[monthlyRevenue.length - 1];
const prevMonth = monthlyRevenue[monthlyRevenue.length - 2];
const margin = ((latest.profit / latest.revenue) * 100).toFixed(1);

function heatColor(value) {
  if (value < 3000) return 'bg-brand-100 dark:bg-brand-500/10';
  if (value < 5500) return 'bg-brand-300 dark:bg-brand-500/30';
  if (value < 7500) return 'bg-brand-500 dark:bg-brand-500/60';
  return 'bg-brand-700 dark:bg-brand-500';
}

export default function Analytics() {
  const weeks = ['W1', 'W2', 'W3', 'W4'];
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-ink-900 dark:text-white">Profit Analytics</h1>
        <p className="text-sm text-ink-500 mt-1">Deep dive into revenue, expenses, and profitability.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <KpiCard label="Revenue" value={formatCurrency(latest.revenue, { compact: true })} change={Number((((latest.revenue - prevMonth.revenue) / prevMonth.revenue) * 100).toFixed(1))} icon={IndianRupee} tone="brand" />
        <KpiCard label="Expenses" value={formatCurrency(latest.expenses, { compact: true })} change={Number((((latest.expenses - prevMonth.expenses) / prevMonth.expenses) * 100).toFixed(1))} icon={TrendingDown} tone="rose" />
        <KpiCard label="Gross Profit" value={formatCurrency(latest.profit, { compact: true })} change={Number((((latest.profit - prevMonth.profit) / prevMonth.profit) * 100).toFixed(1))} icon={TrendingUp} tone="emerald" />
        <KpiCard label="Net Profit" value={formatCurrency(Math.round(latest.profit * 0.88), { compact: true })} change={5.2} icon={IndianRupee} tone="sky" />
        <KpiCard label="Profit Margin" value={`${margin}%`} change={1.8} icon={Percent} tone="amber" />
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <ChartCard title="Revenue Trend" subtitle="Monthly revenue over the year" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={monthlyRevenue}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip formatter={(v) => formatCurrency(v)} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={2.5} fill="url(#revGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Expense Breakdown" subtitle="Where money goes">
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={expenseBreakdown} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} paddingAngle={2}>
                {expenseBreakdown.map((entry, i) => (
                  <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(v) => `${v}%`} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {expenseBreakdown.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between text-xs text-ink-500">
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />{d.name}</span>
                {d.value}%
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <ChartCard title="Monthly Profit" subtitle="Net profit trend" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={profitTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-ink-100 dark:stroke-ink-800" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#8c8ca3' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#8c8ca3' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip formatter={(v) => formatCurrency(v)} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Bar dataKey="profit" fill="#10b981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Profit Heatmap" subtitle="Daily profit intensity, last 4 weeks">
          <div className="grid gap-1.5" style={{ gridTemplateColumns: `40px repeat(${weeks.length}, 1fr)` }}>
            <div />
            {weeks.map((w) => <div key={w} className="text-[10px] text-ink-400 text-center">{w}</div>)}
            {days.map((day) => (
              <Fragment key={day}>
                <div className="text-[10px] text-ink-400 flex items-center">{day}</div>
                {weeks.map((w) => {
                  const cell = profitHeatmap.find((c) => c.day === day && c.week === w);
                  return (
                    <div
                      key={day + w}
                      title={`${day} ${w}: ${formatCurrency(cell?.value || 0)}`}
                      className={`aspect-square rounded-md ${heatColor(cell?.value || 0)}`}
                    />
                  );
                })}
              </Fragment>
            ))}
          </div>
          <div className="flex items-center gap-2 mt-3 text-[10px] text-ink-400">
            <span>Low</span>
            <span className="w-3 h-3 rounded bg-brand-100 dark:bg-brand-500/10" />
            <span className="w-3 h-3 rounded bg-brand-300 dark:bg-brand-500/30" />
            <span className="w-3 h-3 rounded bg-brand-500 dark:bg-brand-500/60" />
            <span className="w-3 h-3 rounded bg-brand-700 dark:bg-brand-500" />
            <span>High</span>
          </div>
        </ChartCard>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <Card className="p-5">
          <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-4 flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-brand-600" /> Top Products by Revenue
          </h3>
          <Table columns={['Product', 'Units', 'Revenue']}>
            {topProducts.slice(0, 6).map((p) => (
              <Tr key={p.name}>
                <Td>{p.name}</Td>
                <Td>{p.unitsSold}</Td>
                <Td className="font-medium">{formatCurrency(p.revenue)}</Td>
              </Tr>
            ))}
          </Table>
        </Card>
        <Card className="p-5">
          <h3 className="font-display font-semibold text-sm text-ink-900 dark:text-white mb-4">Top Customers by Spend</h3>
          <Table columns={['Customer', 'Orders', 'Total Spend']}>
            {topCustomers.map((c) => (
              <Tr key={c.name}>
                <Td>{c.name}</Td>
                <Td>{c.orders}</Td>
                <Td className="font-medium">{formatCurrency(c.spend)}</Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </div>
  );
}
