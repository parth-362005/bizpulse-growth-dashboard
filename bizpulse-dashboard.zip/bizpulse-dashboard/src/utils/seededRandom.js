// Small deterministic PRNG (mulberry32) so dummy data stays stable across reloads.
export function mulberry32(seed) {
  let a = seed;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const rng = mulberry32(42);

export function randInt(min, max, r = rng) {
  return Math.floor(r() * (max - min + 1)) + min;
}

export function randFloat(min, max, decimals = 2, r = rng) {
  const v = r() * (max - min) + min;
  return Number(v.toFixed(decimals));
}

export function pick(arr, r = rng) {
  return arr[Math.floor(r() * arr.length)];
}
