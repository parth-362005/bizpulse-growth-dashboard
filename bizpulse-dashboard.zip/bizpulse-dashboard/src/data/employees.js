import { mulberry32, randInt, pick } from '../utils/seededRandom';

const r = mulberry32(303);

const names = [
  ['Rajesh', 'Deshmukh', 'Admin'],
  ['Suman', 'Patil', 'Manager'],
  ['Vikas', 'Kulkarni', 'Cashier'],
  ['Anita', 'Joshi', 'Cashier'],
  ['Nitin', 'Shinde', 'Manager'],
  ['Pallavi', 'Kale', 'Cashier'],
  ['Ramesh', 'Gaikwad', 'Cashier'],
  ['Sunita', 'Bhosale', 'Inventory Staff'],
];

const permissionsByRole = {
  Admin: ['Full Access', 'Manage Employees', 'View Reports', 'Edit Settings', 'Billing'],
  Manager: ['View Reports', 'Manage Inventory', 'Billing', 'Manage Customers'],
  Cashier: ['Billing', 'View Products'],
  'Inventory Staff': ['Manage Inventory', 'View Products'],
};

export const employees = names.map(([fn, ln, role], i) => {
  const joinedDaysAgo = randInt(60, 1800, r);
  const joined = new Date();
  joined.setDate(joined.getDate() - joinedDaysAgo);
  return {
    id: `EMP${String(i + 1).padStart(3, '0')}`,
    name: `${fn} ${ln}`,
    avatarInitials: `${fn[0]}${ln[0]}`,
    role,
    phone: `+91 9${randInt(100000000, 999999999, r)}`,
    email: `${fn.toLowerCase()}.${ln.toLowerCase()}@shreeganeshstore.in`,
    permissions: permissionsByRole[role],
    joinedDate: joined.toISOString(),
    attendanceThisMonth: randInt(18, 26, r),
    totalWorkingDays: 26,
    performanceScore: randInt(68, 98, r),
    salaryStatus: pick(['Paid', 'Pending', 'Processing'], r),
    monthlySalary: role === 'Admin' ? 0 : randInt(14000, 32000, r),
  };
});
