import { mulberry32, randInt, randFloat, pick } from '../utils/seededRandom';

const r = mulberry32(101);

export const categories = [
  'Grocery',
  'Dairy',
  'Beverages',
  'Snacks',
  'Personal Care',
  'Household',
  'Stationery',
  'Bakery',
];

export const suppliers = [
  'Patil Wholesale Traders',
  'Maharashtra Dairy Co.',
  'Sunrise FMCG Distributors',
  'Deccan Agro Suppliers',
  'National Beverages Pvt Ltd',
  'Kirana Bazaar Distributors',
];

const productNames = {
  Grocery: ['Basmati Rice 5kg', 'Toor Dal 1kg', 'Sunflower Oil 1L', 'Wheat Atta 10kg', 'Sugar 1kg', 'Salt 1kg', 'Moong Dal 1kg', 'Besan 1kg', 'Poha 500g', 'Rava/Sooji 1kg'],
  Dairy: ['Amul Milk 500ml', 'Paneer 200g', 'Curd 400g', 'Butter 100g', 'Cheese Slices', 'Ghee 1L', 'Flavoured Milk 200ml'],
  Beverages: ['Coca-Cola 750ml', 'Frooti 200ml', 'Real Juice 1L', 'Bisleri Water 1L', 'Tata Tea Gold 250g', 'Nescafe Classic 100g', 'Sting Energy Drink'],
  Snacks: ['Lays Classic 52g', 'Haldiram Bhujia 200g', 'Parle-G Biscuit', 'Oreo Biscuit', 'Kurkure Masala Munch', 'Bikaji Namkeen 200g'],
  'Personal Care': ['Colgate Toothpaste 100g', 'Dove Soap 100g', 'Head & Shoulders 180ml', 'Nivea Body Lotion', 'Gillette Razor', 'Patanjali Aloe Gel'],
  Household: ['Vim Dishwash Bar', 'Surf Excel 1kg', 'Harpic Toilet Cleaner', 'Good Knight Refill', 'Odonil Air Freshener', 'Scotch Brite Scrub Pad'],
  Stationery: ['Classmate Notebook', 'Reynolds Pen Pack', 'A4 Paper Ream', 'Camlin Geometry Box', 'Sticky Notes Pack'],
  Bakery: ['Britannia Bread', 'Cake Rusk 200g', 'Cream Biscuits', 'Whole Wheat Bread'],
};

function buildProducts() {
  let id = 1;
  const list = [];
  for (const cat of categories) {
    for (const name of productNames[cat]) {
      const purchasePrice = randFloat(15, 450, 0, r);
      const margin = randFloat(1.15, 1.55, 2, r);
      const sellingPrice = Math.round(purchasePrice * margin);
      const stock = randInt(0, 220, r);
      const lowStockThreshold = randInt(10, 30, r);
      const expiryMonths = randInt(2, 18, r);
      const expiry = new Date();
      expiry.setMonth(expiry.getMonth() + expiryMonths);
      list.push({
        id: `PRD${String(id).padStart(4, '0')}`,
        sku: `SKU-${cat.slice(0, 3).toUpperCase()}-${1000 + id}`,
        name,
        category: cat,
        image: null,
        purchasePrice,
        sellingPrice,
        stock,
        lowStockThreshold,
        isLowStock: stock <= lowStockThreshold,
        supplier: pick(suppliers, r),
        expiryDate: expiry.toISOString(),
        gstRate: pick([5, 12, 18], r),
        unit: pick(['pcs', 'kg', 'ltr', 'pack'], r),
      });
      id++;
    }
  }
  return list;
}

export const products = buildProducts();

export const lowStockProducts = products.filter((p) => p.isLowStock);
