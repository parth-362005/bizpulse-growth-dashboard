import { mulberry32, randInt, pick } from '../utils/seededRandom';
import { customers } from './customers';

const r = mulberry32(606);

// In-app notifications (bell dropdown)
export const appNotifications = [
  { id: 1, title: 'Low stock alert', message: 'Sugar 1kg has only 6 units left.', type: 'warning', time: '10 min ago', read: false },
  { id: 2, title: 'New order received', message: 'Order #ORD1211 placed by Priya Patil.', type: 'success', time: '42 min ago', read: false },
  { id: 3, title: 'Payment overdue', message: 'Invoice INV2405 is overdue by 4 days.', type: 'error', time: '2 hours ago', read: false },
  { id: 4, title: 'GST filing reminder', message: 'Monthly GST return due in 5 days.', type: 'info', time: '5 hours ago', read: true },
  { id: 5, title: 'Employee check-in', message: 'Vikas Kulkarni checked in at 9:58 AM.', type: 'info', time: '1 day ago', read: true },
];

// WhatsApp notification history
const waTypes = ['Invoice Sent', 'Payment Reminder', 'Promotion', 'Order Confirmation'];
const waTemplates = {
  'Invoice Sent': 'Hi {name}, your invoice {inv} of ₹{amt} has been generated. Thank you for shopping with Shree Ganesh Store!',
  'Payment Reminder': 'Hi {name}, a gentle reminder that ₹{amt} is pending against invoice {inv}. Please clear at your convenience.',
  Promotion: 'Hi {name}, enjoy 10% off on all Dairy products this weekend only at Shree Ganesh Store!',
  'Order Confirmation': 'Hi {name}, your order {inv} has been confirmed and will be ready for pickup in 20 minutes.',
};
const waStatuses = ['Delivered', 'Read', 'Sent', 'Failed'];

export const whatsappNotifications = Array.from({ length: 18 }, (_, i) => {
  const cust = pick(customers, r);
  const type = pick(waTypes, r);
  const inv = `INV${randInt(2400, 2426, r)}`;
  const amt = randInt(200, 5400, r);
  const hoursAgo = randInt(1, 240, r);
  const date = new Date();
  date.setHours(date.getHours() - hoursAgo);
  return {
    id: `WA${1000 + i}`,
    customer: cust.name,
    phone: cust.phone,
    type,
    message: waTemplates[type].replace('{name}', cust.name.split(' ')[0]).replace('{inv}', inv).replace('{amt}', amt),
    status: pick(waStatuses, r),
    date: date.toISOString(),
    timeline: [
      { step: 'Queued', done: true },
      { step: 'Sent', done: true },
      { step: 'Delivered', done: r() > 0.2 },
      { step: 'Read', done: r() > 0.5 },
    ],
  };
});

// AI Sales Prediction data
export const forecastGraph = Array.from({ length: 14 }, (_, i) => {
  const date = new Date();
  date.setDate(date.getDate() + i);
  const base = 16000 + i * 320;
  return {
    date: date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
    actual: i < 6 ? base + randInt(-1200, 1200, r) : null,
    predicted: base + randInt(-800, 1800, r),
  };
});

export const seasonalSales = ['Diwali', 'Christmas', 'New Year', 'Holi', 'Summer', 'Monsoon', 'Independence Day'].map((season) => ({
  season,
  growth: randInt(8, 42, r),
}));

export const demandPrediction = [
  { product: 'Milk 500ml', currentStock: 24, predictedDemand: 180, restockIn: 2 },
  { product: 'Sugar 1kg', currentStock: 6, predictedDemand: 90, restockIn: 3 },
  { product: 'Basmati Rice 5kg', currentStock: 14, predictedDemand: 60, restockIn: 5 },
  { product: 'Sunflower Oil 1L', currentStock: 9, predictedDemand: 75, restockIn: 4 },
  { product: 'Toor Dal 1kg', currentStock: 18, predictedDemand: 55, restockIn: 6 },
];

export const aiInsights = [
  { icon: 'TrendingUp', text: 'Milk demand expected to increase by 24% next week due to festival season.', tone: 'positive' },
  { icon: 'AlertTriangle', text: 'Restock Sugar within 3 days to avoid stockouts.', tone: 'warning' },
  { icon: 'Sparkles', text: 'Festival sales expected to rise by 28% over the next 10 days.', tone: 'positive' },
  { icon: 'CalendarClock', text: 'Highest sales expected on Friday this week — plan staffing accordingly.', tone: 'info' },
  { icon: 'PackageSearch', text: 'Sunflower Oil is trending 18% above forecast — consider a bulk order.', tone: 'info' },
];

export const predictionKpis = {
  expectedRevenue: 612000,
  expectedRevenueChange: 9.4,
  expectedSales: 3120,
  expectedSalesChange: 6.1,
  restockAlerts: demandPrediction.filter((d) => d.currentStock < d.predictedDemand * 0.2).length,
  demandForecastAccuracy: 92.4,
};

// GST report data
export const monthlyGST = [
  { month: 'Jan', salesTax: 42300, purchaseTax: 28100, net: 14200 },
  { month: 'Feb', salesTax: 39800, purchaseTax: 26500, net: 13300 },
  { month: 'Mar', salesTax: 46200, purchaseTax: 31200, net: 15000 },
  { month: 'Apr', salesTax: 44100, purchaseTax: 29800, net: 14300 },
  { month: 'May', salesTax: 48700, purchaseTax: 33100, net: 15600 },
  { month: 'Jun', salesTax: 51200, purchaseTax: 34700, net: 16500 },
];

export const quarterlyGST = [
  { quarter: 'Q1 FY25-26', salesTax: 128300, purchaseTax: 85800, net: 42500 },
  { quarter: 'Q2 FY25-26', salesTax: 144000, purchaseTax: 97600, net: 46400 },
  { quarter: 'Q3 FY24-25', salesTax: 121500, purchaseTax: 81200, net: 40300 },
  { quarter: 'Q4 FY24-25', salesTax: 133700, purchaseTax: 90100, net: 43600 },
];

export const gstRateSummary = [
  { rate: '5%', taxableValue: 182400, taxAmount: 9120 },
  { rate: '12%', taxableValue: 246800, taxAmount: 29616 },
  { rate: '18%', taxableValue: 198300, taxAmount: 35694 },
];

// Recent activity timeline for dashboard
export const recentActivities = [
  { id: 1, text: 'New invoice INV2426 generated for Amit Sharma', time: '8 min ago', icon: 'FileText' },
  { id: 2, text: 'Vikas Kulkarni checked in for the day', time: '1 hour ago', icon: 'UserCheck' },
  { id: 3, text: 'Stock updated: Basmati Rice 5kg (+40 units)', time: '2 hours ago', icon: 'PackagePlus' },
  { id: 4, text: 'Payment of ₹3,400 received from Priya Patil', time: '3 hours ago', icon: 'IndianRupee' },
  { id: 5, text: 'WhatsApp promotion sent to 28 customers', time: '5 hours ago', icon: 'MessageCircle' },
  { id: 6, text: 'New customer Rina Salvi added', time: 'Yesterday', icon: 'UserPlus' },
];

export const businessTips = [
  'Bundle slow-moving items with bestsellers to clear inventory faster.',
  'Send WhatsApp reminders 2 days before payment due dates to reduce overdue invoices.',
  'Customers with Gold/Platinum tier respond well to early access offers.',
  'Restocking before Friday can capture your weekly demand peak.',
];
