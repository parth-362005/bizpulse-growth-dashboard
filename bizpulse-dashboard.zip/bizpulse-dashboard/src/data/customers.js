import { mulberry32, randInt, randFloat, pick } from '../utils/seededRandom';

const r = mulberry32(202);

const firstNames = ['Amit', 'Priya', 'Rahul', 'Sneha', 'Vikram', 'Anjali', 'Suresh', 'Kavita', 'Rohan', 'Meera', 'Sanjay', 'Pooja', 'Arjun', 'Neha', 'Karan', 'Divya', 'Manoj', 'Swati', 'Deepak', 'Rina'];
const lastNames = ['Sharma', 'Patil', 'Deshmukh', 'Kulkarni', 'Joshi', 'Gupta', 'Reddy', 'Nair', 'Iyer', 'Chavan', 'Shinde', 'Bhosale', 'Kale', 'Salvi', 'Mehta'];
const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];
const notesPool = [
  'Prefers home delivery on weekends.',
  'Always asks for the latest offers.',
  'Bulk buyer for festival season.',
  'Pays via UPI mostly.',
  'Occasionally delays payment by a few days.',
  'Loyal customer since store opening.',
  'Runs a small tea stall, buys in bulk.',
  '',
];

function buildCustomers() {
  const list = [];
  for (let i = 1; i <= 32; i++) {
    const fn = pick(firstNames, r);
    const ln = pick(lastNames, r);
    const totalPurchases = randInt(3, 140, r);
    const totalSpend = randInt(800, 185000, r);
    const outstanding = r() > 0.72 ? randInt(200, 6500, r) : 0;
    const joinDaysAgo = randInt(15, 1400, r);
    const joined = new Date();
    joined.setDate(joined.getDate() - joinDaysAgo);
    const lastPurchaseDaysAgo = randInt(0, 60, r);
    const lastPurchase = new Date();
    lastPurchase.setDate(lastPurchase.getDate() - lastPurchaseDaysAgo);

    list.push({
      id: `CUST${String(i).padStart(4, '0')}`,
      name: `${fn} ${ln}`,
      phone: `+91 9${randInt(100000000, 999999999, r)}`,
      email: `${fn.toLowerCase()}.${ln.toLowerCase()}@example.com`,
      avatarInitials: `${fn[0]}${ln[0]}`,
      tier: pick(tiers, r),
      totalPurchases,
      totalSpend,
      outstanding,
      loyaltyPoints: randInt(0, 2400, r),
      joinedDate: joined.toISOString(),
      lastPurchaseDate: lastPurchase.toISOString(),
      notes: pick(notesPool, r),
      purchaseHistory: Array.from({ length: Math.min(5, totalPurchases) }, (_, idx) => {
        const daysAgo = randInt(1, 90, r) + idx * 4;
        const d = new Date();
        d.setDate(d.getDate() - daysAgo);
        return {
          invoiceId: `INV${randInt(1000, 9999, r)}`,
          date: d.toISOString(),
          amount: randInt(150, 6200, r),
          items: randInt(1, 12, r),
        };
      }),
    });
  }
  return list;
}

export const customers = buildCustomers();
