import { mulberry32, randInt, pick } from '../utils/seededRandom';
import { products } from './products';
import { customers } from './customers';

const r = mulberry32(505);

const statuses = ['Paid', 'Pending', 'Overdue'];
const paymentMethods = ['Cash', 'UPI', 'Card'];

function buildInvoiceItems() {
  const count = randInt(1, 6, r);
  const items = [];
  const used = new Set();
  for (let i = 0; i < count; i++) {
    let p = pick(products, r);
    let guard = 0;
    while (used.has(p.id) && guard < 10) {
      p = pick(products, r);
      guard++;
    }
    used.add(p.id);
    const qty = randInt(1, 8, r);
    items.push({
      name: p.name,
      sku: p.sku,
      qty,
      price: p.sellingPrice,
      gstRate: p.gstRate,
      total: qty * p.sellingPrice,
    });
  }
  return items;
}

export const invoices = Array.from({ length: 26 }, (_, i) => {
  const daysAgo = randInt(0, 75, r);
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  const customer = r() > 0.15 ? pick(customers, r) : { name: 'Walk-in Customer', phone: '—' };
  const items = buildInvoiceItems();
  const subtotal = items.reduce((s, it) => s + it.total, 0);
  const gstTotal = items.reduce((s, it) => s + (it.total * it.gstRate) / 100, 0);
  const discount = r() > 0.7 ? Math.round(subtotal * 0.05) : 0;
  const grandTotal = Math.round(subtotal + gstTotal - discount);

  return {
    id: `INV${String(2400 + i)}`,
    date: date.toISOString(),
    customer: customer.name,
    customerPhone: customer.phone,
    items,
    subtotal: Math.round(subtotal),
    gstTotal: Math.round(gstTotal),
    discount,
    grandTotal,
    status: pick(statuses, r),
    paymentMethod: pick(paymentMethods, r),
  };
}).sort((a, b) => new Date(b.date) - new Date(a.date));
