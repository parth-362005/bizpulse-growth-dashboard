export const businessProfile = {
  name: 'Shree Ganesh General Store',
  ownerName: 'Rajesh Deshmukh',
  logoInitials: 'SG',
  gstNumber: '27ABCDE1234F1Z5',
  phone: '+91 98765 43210',
  email: 'contact@shreeganeshstore.in',
  address: '12, Market Yard Road, Sholapur, Maharashtra – 413001',
  since: '2018',
  plan: 'Growth Plan',
};

export const currentUser = {
  name: 'Rajesh Deshmukh',
  role: 'Owner / Admin',
  email: 'rajesh@shreeganeshstore.in',
  avatarInitials: 'RD',
};
