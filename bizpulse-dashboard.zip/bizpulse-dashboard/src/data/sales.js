import { mulberry32, randInt, randFloat, pick } from '../utils/seededRandom';
import { products } from './products';

const r = mulberry32(404);

const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
export const weeklySales = weekDays.map((day) => ({
  day,
  sales: randInt(8000, 32000, r),
  orders: randInt(30, 140, r),
}));

const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const monthlyRevenue = monthNames.map((month) => {
  const revenue = randInt(280000, 620000, r);
  const expenses = Math.round(revenue * randFloat(0.55, 0.75, 2, r));
  return {
    month,
    revenue,
    expenses,
    profit: revenue - expenses,
  };
});

export const profitTrend = monthlyRevenue.map((m) => ({
  month: m.month,
  profit: m.profit,
  margin: Number(((m.profit / m.revenue) * 100).toFixed(1)),
}));

export const revenueDistribution = [
  { name: 'Grocery', value: 34 },
  { name: 'Dairy', value: 18 },
  { name: 'Beverages', value: 14 },
  { name: 'Snacks', value: 12 },
  { name: 'Personal Care', value: 10 },
  { name: 'Household', value: 8 },
  { name: 'Others', value: 4 },
];

export const topProducts = [...products]
  .sort(() => r() - 0.5)
  .slice(0, 8)
  .map((p) => ({
    name: p.name,
    unitsSold: randInt(40, 480, r),
    revenue: randInt(3000, 68000, r),
    category: p.category,
  }))
  .sort((a, b) => b.revenue - a.revenue);

export const topCustomers = [
  { name: 'Amit Sharma', spend: 84200, orders: 46 },
  { name: 'Priya Patil', spend: 71500, orders: 38 },
  { name: 'Rahul Deshmukh', spend: 64300, orders: 29 },
  { name: 'Sneha Kulkarni', spend: 58900, orders: 33 },
  { name: 'Vikram Joshi', spend: 51200, orders: 22 },
];

// Recent orders for dashboard table
const orderStatuses = ['Completed', 'Pending', 'Processing', 'Cancelled'];
const paymentMethods = ['Cash', 'UPI', 'Card'];
export const recentOrders = Array.from({ length: 12 }, (_, i) => {
  const hoursAgo = randInt(1, 96, r);
  const date = new Date();
  date.setHours(date.getHours() - hoursAgo);
  const itemCount = randInt(1, 9, r);
  return {
    id: `ORD${1200 + i}`,
    customer: pick(['Amit Sharma', 'Priya Patil', 'Rahul Deshmukh', 'Sneha Kulkarni', 'Walk-in Customer', 'Vikram Joshi', 'Anjali Nair'], r),
    date: date.toISOString(),
    items: itemCount,
    amount: randInt(120, 8600, r),
    payment: pick(paymentMethods, r),
    status: pick(orderStatuses, r),
  };
});

export const profitHeatmap = Array.from({ length: 7 }, (_, dayIdx) =>
  Array.from({ length: 4 }, (_, weekIdx) => ({
    day: weekDays[dayIdx],
    week: `W${weekIdx + 1}`,
    value: randInt(1000, 9500, r),
  }))
).flat();

export const expenseBreakdown = [
  { name: 'Stock Purchase', value: 58 },
  { name: 'Staff Salaries', value: 18 },
  { name: 'Rent', value: 10 },
  { name: 'Utilities', value: 6 },
  { name: 'Marketing', value: 4 },
  { name: 'Others', value: 4 },
];

export const todayStats = {
  todaySales: 18420,
  todaySalesChange: 12.4,
  todayOrders: 64,
  todayOrdersChange: 5.1,
  monthlyRevenue: monthlyRevenue[monthlyRevenue.length - 1].revenue,
  monthlyRevenueChange: 8.7,
  netProfit: monthlyRevenue[monthlyRevenue.length - 1].profit,
  netProfitChange: -2.3,
  lowStockCount: products.filter((p) => p.isLowStock).length,
  totalCustomers: 32,
  totalCustomersChange: 6.0,
};
