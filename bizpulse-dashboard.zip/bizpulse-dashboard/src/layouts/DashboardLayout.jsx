import { Outlet } from 'react-router-dom';
import Sidebar from '../components/layout/Sidebar';
import Navbar from '../components/layout/Navbar';
import { useApp } from '../context/AppContext';
import ToastContainer from '../components/ui/Toast';

export default function DashboardLayout() {
  const { sidebarCollapsed } = useApp();

  return (
    <div className="min-h-screen bg-ink-50 dark:bg-ink-950">
      <Sidebar />
      <div className={`transition-all duration-300 ${sidebarCollapsed ? 'lg:pl-[76px]' : 'lg:pl-64'}`}>
        <Navbar />
        <main className="p-4 lg:p-6 max-w-[1600px] mx-auto animate-fade-in">
          <Outlet />
        </main>
      </div>
      <ToastContainer />
    </div>
  );
}
